DARK ALPHA FF OPTIMIZER - ANDROID BUILD NOTES

මෙය ඔයා දුන් Original React + Vite project එකමයි. Android APK එකක් සෑදීමට Capacitor wrapper එක එක් කර ඇත.

වැදගත්:
- මෙය Free Fire game files වෙනස් නොකරන fair-play utility එකකි.
- FPS අගය App/WebView එකේ rendering performance එක මනින එකක්; Free Fire ඇතුළත FPS අගය නොවේ.
- Android සාමාන්‍ය permissions වලින් වෙනත් App එකක RAM නිදහස් කිරීම, game FPS බලෙන් වැඩි කිරීම හෝ game process එක වෙනස් කිරීම කළ නොහැක.

APK build කිරීම සඳහා අවශ්‍ය:
- Node.js 18+
- Android Studio + Android SDK
- Java 17

Build commands:
1. npm install
2. npm run build
3. npx cap add android   (පළමු වරට පමණි)
4. npx cap sync android
5. npx cap open android
Android Studio තුළ Build > Build APK(s).

Package ID: com.darkalpha.ffoptimizer
App name: DARK ALPHA FF OPTIMIZER
