export type FeatureCategory =
  | 'performance'
  | 'sensitivity'
  | 'network'
  | 'system'
  | 'guides';

export type PerformancePreset = 'ultra_2gb' | 'balanced' | 'esports_max';

export type FFPackageType = 'com.dts.freefireth' | 'com.dts.freefiremax';

export type InteractiveToolType =
  | 'fps_live'
  | 'ram_cpu_live'
  | 'battery_live'
  | 'launcher_modal'
  | 'bg_apps_checklist'
  | 'sensitivity_studio'
  | 'dpi_calculator'
  | 'hud_visualizer'
  | 'storage_live'
  | 'touch_test'
  | 'brightness_test'
  | 'network_speed_test'
  | 'data_calculator'
  | 'gaming_timer'
  | 'audio_pan_test'
  | 'troubleshooter'
  | 'quick_device_check'
  | 'device_info_live'
  | 'custom_profiles'
  | 'history_log'
  | 'about_flutter'
  | 'guide_only';

export interface OptimizerFeature {
  id: number;
  code: string;
  title: string;
  titleSi: string;
  category: FeatureCategory;
  shortDesc: string;
  shortDescSi: string;
  tag: string;
  toolType: InteractiveToolType;
  androidIntentAction?: string;
  androidIntentLabel?: string;
  steps: string[];
  proTip: string;
  fairPlayNote?: string;
}

export interface SensitivitySet {
  id: string;
  name: string;
  deviceTier: string;
  general: number;
  redDot: number;
  scope2x: number;
  scope4x: number;
  sniperScope: number;
  freeLook: number;
  fireButtonSize: number;
  recommendedDpi: string;
}

export interface CustomGamingProfile {
  id: string;
  name: string;
  ffPackage: FFPackageType;
  perfMode: PerformancePreset;
  lowRamMode: boolean;
  graphicsPreset: 'Smooth' | 'Standard' | 'Ultra';
  fpsTarget: 'Normal (30)' | 'High (60)';
  sensitivityId: string;
  createdAt: string;
}

export interface HistoryLogEntry {
  id: string;
  timestamp: string;
  action: string;
  detail: string;
  category: 'launch' | 'diagnostic' | 'profile' | 'network' | 'system';
}

export interface RealDeviceTelemetry {
  fps: number;
  frameTimeMs: number;
  droppedFrames: number;
  estimatedRefreshHz: number;
  deviceMemoryGb: number | null;
  jsHeapUsedMb: number | null;
  jsHeapLimitMb: number | null;
  cpuCores: number | null;
  batteryLevel: number | null;
  batteryCharging: boolean | null;
  batteryDischargingTime: number | null;
  online: boolean;
  connectionType: string;
  effectiveType: string;
  downlinkMbps: number | null;
  rttMs: number | null;
  storageUsedMb: number | null;
  storageQuotaMb: number | null;
  screenWidth: number;
  screenHeight: number;
  devicePixelRatio: number;
  platform: string;
  userAgent: string;
  isAndroid: boolean;
}
