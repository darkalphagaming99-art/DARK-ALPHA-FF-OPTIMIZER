export interface FlutterFileEntry {
  filename: string;
  path: string;
  language: string;
  description: string;
  code: string;
}

export const FLUTTER_PROJECT_FILES: FlutterFileEntry[] = [
  {
    filename: 'pubspec.yaml',
    path: 'pubspec.yaml',
    language: 'yaml',
    description: 'Lightweight Flutter dependencies optimized for 2GB RAM Android devices.',
    code: `name: dark_alpha_ff_optimizer
description: DARK ALPHA FF OPTIMIZER - Fair-Play Android Gaming Utility & Launcher
publish_to: 'none'
version: 1.0.0+1

environment:
  sdk: '>=3.2.0 <4.0.0'

dependencies:
  flutter:
    sdk: flutter
  battery_plus: ^6.0.1
  connectivity_plus: ^6.0.3
  device_info_plus: ^10.1.0
  android_intent_plus: ^5.0.2
  shared_preferences: ^2.2.3

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^3.0.0

flutter:
  uses-material-design: true
`,
  },
  {
    filename: 'MainActivity.kt',
    path: 'android/app/src/main/kotlin/com/darkalpha/ffoptimizer/MainActivity.kt',
    language: 'kotlin',
    description: 'Native Android MethodChannel for launching Free Fire, reading real ActivityManager RAM, thermal status, and storage.',
    code: `package com.darkalpha.ffoptimizer

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val CHANNEL = "com.darkalpha.ffoptimizer/native"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "launchFreeFire" -> {
                    val packageName = call.argument<String>("packageName") ?: "com.dts.freefireth"
                    val launched = launchGamePackage(packageName)
                    result.success(launched)
                }
                "isPackageInstalled" -> {
                    val packageName = call.argument<String>("packageName") ?: "com.dts.freefireth"
                    result.success(isAppInstalled(packageName))
                }
                "getRealMemoryInfo" -> {
                    val actManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                    val memInfo = ActivityManager.MemoryInfo()
                    actManager.getMemoryInfo(memInfo)
                    val totalMb = memInfo.totalMem / (1024 * 1024)
                    val availMb = memInfo.availMem / (1024 * 1024)
                    result.success(mapOf(
                        "totalMb" to totalMb,
                        "availMb" to availMb,
                        "lowMemory" to memInfo.lowMemory
                    ))
                }
                "getRealBatteryTemp" -> {
                    val intent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                    val tempTenths = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
                    val tempCelsius = if (tempTenths > 0) tempTenths / 10.0 else -1.0
                    result.success(tempCelsius)
                }
                "getRealStorageInfo" -> {
                    val stat = StatFs(Environment.getDataDirectory().path)
                    val totalGb = (stat.blockCountLong * stat.blockSizeLong) / (1024.0 * 1024.0 * 1024.0)
                    val freeGb = (stat.availableBlocksLong * stat.blockSizeLong) / (1024.0 * 1024.0 * 1024.0)
                    result.success(mapOf(
                        "totalGb" to String.format("%.1f", totalGb),
                        "freeGb" to String.format("%.1f", freeGb)
                    ))
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun isAppInstalled(packageName: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                packageManager.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                packageManager.getPackageInfo(packageName, 0)
            }
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    private fun launchGamePackage(packageName: String): Boolean {
        val launchIntent: Intent? = packageManager.getLaunchIntentForPackage(packageName)
        return if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launchIntent)
            true
        } else {
            false
        }
    }
}
`,
  },
  {
    filename: 'AndroidManifest.xml',
    path: 'android/app/src/main/AndroidManifest.xml',
    language: 'xml',
    description: 'Android 11+ <queries> visibility for Free Fire (com.dts.freefireth) and Free Fire MAX (com.dts.freefiremax).',
    code: `<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

    <!-- Required on Android 11+ to detect & launch Free Fire packages cleanly -->
    <queries>
        <package android:name="com.dts.freefireth" />
        <package android:name="com.dts.freefiremax" />
    </queries>

    <application
        android:label="DARK ALPHA FF OPTIMIZER"
        android:name="\${applicationName}"
        android:icon="@mipmap/ic_launcher"
        android:hardwareAccelerated="true">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTop"
            android:theme="@style/LaunchTheme"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|locale|layoutDirection|fontScale|screenLayout|density|uiMode"
            android:windowSoftInputMode="adjustResize">
            <meta-data
                android:name="io.flutter.embedding.android.NormalTheme"
                android:resource="@style/NormalTheme" />
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
        <meta-data
            android:name="flutterEmbedding"
            android:value="2" />
    </application>
</manifest>
`,
  },
  {
    filename: 'main.dart',
    path: 'lib/main.dart',
    language: 'dart',
    description: 'Complete Black & Red Neon DARK ALPHA FF OPTIMIZER Flutter app with real SchedulerBinding FPS, ActivityManager RAM, Battery, Intent Shortcuts, and Game Launcher.',
    code: `import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:android_intent_plus/android_intent.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Color(0xFF060609),
    statusBarIconBrightness: Brightness.light,
  ));
  runApp(const DarkAlphaApp());
}

class DarkAlphaApp extends StatelessWidget {
  const DarkAlphaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'DARK ALPHA FF OPTIMIZER',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF060609),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFFF1E2D),
          secondary: Color(0xFF00E676),
          surface: Color(0xFF0E1016),
        ),
      ),
      home: const DarkAlphaDashboard(),
    );
  }
}

class DarkAlphaDashboard extends StatefulWidget {
  const DarkAlphaDashboard({super.key});

  @override
  State<DarkAlphaDashboard> createState() => _DarkAlphaDashboardState();
}

class _DarkAlphaDashboardState extends State<DarkAlphaDashboard> {
  static const _channel = MethodChannel('com.darkalpha.ffoptimizer/native');

  String _selectedPackage = 'com.dts.freefireth';
  bool _lowRamMode = true;
  double _realFps = 60.0;
  int _totalRamMb = 0;
  int _availRamMb = 0;
  int _batteryLevel = 0;
  double _batteryTemp = -1.0;
  String _networkType = 'Checking...';
  String _deviceModel = 'Android Device';
  int _lastPingMs = -1;
  List<String> _history = [];

  final Battery _battery = Battery();
  Timer? _telemetryTimer;

  @override
  void initState() {
    super.initState();
    _initRealFpsMonitor();
    _loadHardwareStats();
    _telemetryTimer = Timer.periodic(const Duration(seconds: 4), (_) => _loadHardwareStats());
  }

  // Real Flutter SchedulerBinding frame timing FPS monitor (no fake numbers)
  void _initRealFpsMonitor() {
    SchedulerBinding.instance.addTimingsCallback((List<FrameTiming> timings) {
      if (timings.isEmpty || !mounted) return;
      final avgBuildMicros = timings
              .map((t) => t.totalSpan.inMicroseconds)
              .reduce((a, b) => a + b) /
          timings.length;
      if (avgBuildMicros > 0) {
        final measured = (1000000.0 / avgBuildMicros).clamp(1.0, 144.0);
        setState(() => _realFps = measured);
      }
    });
  }

  Future<void> _loadHardwareStats() async {
    try {
      final level = await _battery.batteryLevel;
      final conn = await Connectivity().checkConnectivity();
      final info = await DeviceInfoPlugin().androidInfo;
      final mem = await _channel.invokeMethod<Map>('getRealMemoryInfo');
      final temp = await _channel.invokeMethod<double>('getRealBatteryTemp');
      final prefs = await SharedPreferences.getInstance();

      if (!mounted) return;
      setState(() {
        _batteryLevel = level;
        _networkType = conn.isNotEmpty ? conn.first.name.toUpperCase() : 'OFFLINE';
        _deviceModel = '\${info.manufacturer.toUpperCase()} \${info.model}';
        _totalRamMb = (mem?['totalMb'] as int?) ?? 0;
        _availRamMb = (mem?['availMb'] as int?) ?? 0;
        _batteryTemp = temp ?? -1.0;
        _history = prefs.getStringList('opt_history') ?? [];
      });
    } catch (_) {}
  }

  Future<void> _logAction(String entry) async {
    final prefs = await SharedPreferences.getInstance();
    final now = TimeOfDay.now().format(context);
    final updated = ['[\$now] \$entry', ..._history].take(25).toList();
    await prefs.setStringList('opt_history', updated);
    if (mounted) setState(() => _history = updated);
  }

  Future<void> _launchFreeFire() async {
    await _logAction('Launch requested: \$_selectedPackage');
    final launched = await _channel.invokeMethod<bool>(
          'launchFreeFire',
          {'packageName': _selectedPackage},
        ) ??
        false;

    if (!launched && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: const Color(0xFFFF1E2D),
          content: Text('Package \$_selectedPackage not installed on this device.'),
        ),
      );
    }
  }

  Future<void> _openAndroidSettings(String action) async {
    const intent = AndroidIntent(action: 'android.settings.SETTINGS');
    await AndroidIntent(action: action).launch();
    await _logAction('Opened system settings: \$action');
  }

  Future<void> _runRealPingCheck() async {
    final sw = Stopwatch()..start();
    try {
      final socket = await Socket.connect('1.1.1.1', 53, timeout: const Duration(seconds: 2));
      sw.stop();
      socket.destroy();
      setState(() => _lastPingMs = sw.elapsedMilliseconds);
      await _logAction('Ping check: \${sw.elapsedMilliseconds}ms');
    } catch (_) {
      setState(() => _lastPingMs = 999);
    }
  }

  @override
  void dispose() {
    _telemetryTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final usedRamMb = (_totalRamMb - _availRamMb).clamp(0, _totalRamMb);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF0A0C12),
        title: const Text(
          'DARK ALPHA FF OPTIMIZER',
          style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1.2, fontSize: 16),
        ),
        actions: [
          FilterChip(
            label: Text(_lowRamMode ? '2GB MODE: ON' : '2GB MODE: OFF',
                style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
            selected: _lowRamMode,
            selectedColor: const Color(0xFFFF1E2D),
            onSelected: (v) => setState(() => _lowRamMode = v),
          ),
          const SizedBox(width: 10),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          // Game Launcher Card
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF0E1016),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: const Color(0xFFFF1E2D).withOpacity(0.55)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_deviceModel,
                    style: const TextStyle(color: Color(0xFF9AA3B2), fontSize: 12)),
                const SizedBox(height: 6),
                Row(
                  children: [
                    ChoiceChip(
                      label: const Text('Free Fire'),
                      selected: _selectedPackage == 'com.dts.freefireth',
                      selectedColor: const Color(0xFFFF1E2D),
                      onSelected: (_) =>
                          setState(() => _selectedPackage = 'com.dts.freefireth'),
                    ),
                    const SizedBox(width: 8),
                    ChoiceChip(
                      label: const Text('Free Fire MAX'),
                      selected: _selectedPackage == 'com.dts.freefiremax',
                      selectedColor: const Color(0xFFFF1E2D),
                      onSelected: (_) =>
                          setState(() => _selectedPackage = 'com.dts.freefiremax'),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFF1E2D),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                    onPressed: _launchFreeFire,
                    icon: const Icon(Icons.rocket_launch_rounded),
                    label: const Text(
                      'LAUNCH FREE FIRE',
                      style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.4),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),

          // Real Hardware Telemetry Grid
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 1.65,
            children: [
              _statCard('LIVE UI FPS', '\${_realFps.toStringAsFixed(0)} FPS'),
              _statCard('REAL RAM', '\$usedRamMb / \$_totalRamMb MB'),
              _statCard('BATTERY / TEMP',
                  '\$_batteryLevel% • \${_batteryTemp > 0 ? "\${_batteryTemp.toStringAsFixed(1)}°C" : "N/A"}'),
              _statCard('NETWORK / PING',
                  '\$_networkType • \${_lastPingMs > 0 ? "\${_lastPingMs}ms" : "Tap Test"}'),
            ],
          ),
          const SizedBox(height: 14),

          // Direct Android System Shortcuts
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              ActionChip(
                label: const Text('Wi-Fi Settings'),
                onPressed: () => _openAndroidSettings('android.settings.WIFI_SETTINGS'),
              ),
              ActionChip(
                label: const Text('Mobile Network'),
                onPressed: () => _openAndroidSettings('android.settings.DATA_ROAMING_SETTINGS'),
              ),
              ActionChip(
                label: const Text('Do Not Disturb'),
                onPressed: () => _openAndroidSettings('android.settings.ZEN_MODE_SETTINGS'),
              ),
              ActionChip(
                label: const Text('App Manager'),
                onPressed: () => _openAndroidSettings('android.settings.APPLICATION_SETTINGS'),
              ),
              ActionChip(
                label: const Text('Ping Probe'),
                onPressed: _runRealPingCheck,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _statCard(String title, String value) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF0E1016),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(title, style: const TextStyle(color: Color(0xFF9AA3B2), fontSize: 11)),
          const SizedBox(height: 6),
          Text(value,
              style: const TextStyle(
                  color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
        ],
      ),
    );
  }
}
`,
  },
];
