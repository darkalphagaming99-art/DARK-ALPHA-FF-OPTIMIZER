import React, { useState } from 'react';
import {
  X,
  ExternalLink,
  CheckCircle2,
  ShieldCheck,
  Lightbulb,
  Activity,
  Cpu,
  BatteryCharging,
  Wifi,
  HardDrive,
  Sun,
  Play,
  Plus,
  Trash2,
  Code2,
} from 'lucide-react';
import {
  CustomGamingProfile,
  FFPackageType,
  HistoryLogEntry,
  OptimizerFeature,
  PerformancePreset,
  RealDeviceTelemetry,
} from '../types/optimizer';
import { SpeedTestResult } from '../hooks/useRealTelemetry';
import {
  AudioPanTester,
  BackgroundAppsChecklist,
  DataUsageCalculator,
  DpiSafeCalculator,
  GamingSessionTimer,
  HudLayoutVisualizer,
  TouchScreenTester,
  TroubleshootingMatrix,
} from './InteractiveTools';
import { PRESET_SENSITIVITIES } from '../data/featuresData';

interface FeatureDetailModalProps {
  feature: OptimizerFeature | null;
  onClose: () => void;
  telemetry: RealDeviceTelemetry;
  fpsHistory: number[];
  speedTest: SpeedTestResult | null;
  isTestingSpeed: boolean;
  onRunSpeedTest: () => Promise<SpeedTestResult>;
  customProfiles: CustomGamingProfile[];
  onAddCustomProfile: (profile: CustomGamingProfile) => void;
  onApplyCustomProfile: (profile: CustomGamingProfile) => void;
  historyLog: HistoryLogEntry[];
  onClearHistory: () => void;
  onLogHistory: (
    action: string,
    detail: string,
    category: HistoryLogEntry['category']
  ) => void;
  onOpenFlutterModal: () => void;
  onJumpToSensitivity: () => void;
  onTriggerLaunch: () => void;
}

export const FeatureDetailModal: React.FC<FeatureDetailModalProps> = ({
  feature,
  onClose,
  telemetry,
  fpsHistory,
  speedTest,
  isTestingSpeed,
  onRunSpeedTest,
  customProfiles,
  onAddCustomProfile,
  onApplyCustomProfile,
  historyLog,
  onClearHistory,
  onLogHistory,
  onOpenFlutterModal,
  onJumpToSensitivity,
  onTriggerLaunch,
}) => {
  const [intentNotice, setIntentNotice] = useState<string | null>(null);
  const [testBrightness, setTestBrightness] = useState(65);
  const [scanComplete, setScanComplete] = useState(false);

  // Custom Profile builder states (#48)
  const [profName, setProfName] = useState('');
  const [profPkg, setProfPkg] = useState<FFPackageType>('com.dts.freefireth');
  const [profMode, setProfMode] = useState<PerformancePreset>('ultra_2gb');
  const [profGfx, setProfGfx] = useState<'Smooth' | 'Standard' | 'Ultra'>('Smooth');
  const [profFps, setProfFps] = useState<'Normal (30)' | 'High (60)'>('Normal (30)');

  if (!feature) return null;

  const handleOpenAndroidIntent = (action: string, label: string) => {
    onLogHistory('System Settings Shortcut', `${label} (${action})`, 'system');
    if (telemetry.isAndroid) {
      window.location.href = `intent:#Intent;action=${action};end`;
      setIntentNotice(`Dispatched Android intent: ${action}`);
    } else {
      setIntentNotice(
        `Android Intent (${action}) ready — triggers natively on Android phones & in the Flutter APK.`
      );
    }
  };

  const handleCreateProfile = (e: React.FormEvent) => {
    e.preventDefault();
    const created: CustomGamingProfile = {
      id: `prof_${Date.now()}`,
      name: profName.trim() || `Alpha Squad #${customProfiles.length + 1}`,
      ffPackage: profPkg,
      perfMode: profMode,
      lowRamMode: profMode === 'ultra_2gb',
      graphicsPreset: profGfx,
      fpsTarget: profFps,
      sensitivityId: PRESET_SENSITIVITIES[0].id,
      createdAt: new Date().toLocaleDateString(),
    };
    onAddCustomProfile(created);
    setProfName('');
  };

  const renderInteractiveWidget = () => {
    switch (feature.toolType) {
      case 'fps_live':
        return (
          <div className="bg-[#0A0C12] rounded-xl p-3.5 border border-white/10">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-display font-bold uppercase text-white flex items-center gap-1.5">
                <Activity className="w-4 h-4 text-[#FF1E2D]" />
                <span>Live Hardware Render Telemetry</span>
              </span>
              <span className="font-mono-tech text-xs text-[#00E676]">
                {telemetry.estimatedRefreshHz}Hz Panel
              </span>
            </div>
            <div className="grid grid-cols-3 gap-2 mb-3 text-center">
              <div className="bg-[#11141E] p-2.5 rounded-lg border border-white/5">
                <div className="text-[10px] text-[#9AA3B2]">LIVE FPS</div>
                <div className="font-mono-tech text-xl font-bold text-[#00E676]">
                  {telemetry.fps}
                </div>
              </div>
              <div className="bg-[#11141E] p-2.5 rounded-lg border border-white/5">
                <div className="text-[10px] text-[#9AA3B2]">FRAME TIME</div>
                <div className="font-mono-tech text-xl font-bold text-white">
                  {telemetry.frameTimeMs}ms
                </div>
              </div>
              <div className="bg-[#11141E] p-2.5 rounded-lg border border-white/5">
                <div className="text-[10px] text-[#9AA3B2]">STUTTER SPIKES</div>
                <div className="font-mono-tech text-xl font-bold text-[#FF9F1C]">
                  {telemetry.droppedFrames}
                </div>
              </div>
            </div>
            {/* Sparkline Bar Chart */}
            <div className="flex items-end gap-1 h-12 bg-[#060609] p-2 rounded-lg border border-white/5">
              {fpsHistory.map((val, i) => {
                const heightPct = Math.min(100, Math.max(15, Math.round((val / 120) * 100)));
                return (
                  <div
                    key={i}
                    style={{ height: `${heightPct}%` }}
                    className={`flex-1 rounded-t ${
                      val >= 50 ? 'bg-[#00E676]' : val >= 35 ? 'bg-[#FF9F1C]' : 'bg-[#FF1E2D]'
                    }`}
                  />
                );
              })}
            </div>
          </div>
        );

      case 'ram_cpu_live':
        return (
          <div className="bg-[#0A0C12] rounded-xl p-3.5 border border-white/10 space-y-2.5">
            <div className="flex items-center gap-2 text-xs font-display font-bold uppercase text-white">
              <Cpu className="w-4 h-4 text-[#FF1E2D]" />
              <span>Real Silicon & Memory Readout</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="bg-[#11141E] p-3 rounded-lg border border-white/5">
                <div className="text-[10px] text-[#9AA3B2]">HARDWARE RAM TIER</div>
                <div className="font-mono-tech text-base font-bold text-white mt-0.5">
                  {telemetry.deviceMemoryGb !== null
                    ? `${telemetry.deviceMemoryGb} GB RAM`
                    : 'Android Native API'}
                </div>
                <div className="text-[10px] text-[#5C6475] mt-0.5">
                  {telemetry.jsHeapUsedMb !== null
                    ? `App Heap: ${telemetry.jsHeapUsedMb}MB / ${telemetry.jsHeapLimitMb}MB`
                    : 'Zero fake RAM numbers'}
                </div>
              </div>
              <div className="bg-[#11141E] p-3 rounded-lg border border-white/5">
                <div className="text-[10px] text-[#9AA3B2]">CPU CORES</div>
                <div className="font-mono-tech text-base font-bold text-[#00E676] mt-0.5">
                  {telemetry.cpuCores !== null ? `${telemetry.cpuCores} Logical Cores` : 'Multi-Core'}
                </div>
                <div className="text-[10px] text-[#5C6475] mt-0.5">{telemetry.platform}</div>
              </div>
            </div>
          </div>
        );

      case 'battery_live':
        return (
          <div className="bg-[#0A0C12] rounded-xl p-3.5 border border-white/10">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-display font-bold uppercase text-white flex items-center gap-1.5">
                <BatteryCharging className="w-4 h-4 text-[#00E676]" />
                <span>Real Battery & Thermal Status</span>
              </span>
              <span className="font-mono-tech text-xs text-[#FF9F1C]">Safe &lt; 39°C</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="bg-[#11141E] p-3 rounded-lg border border-white/5">
                <div className="text-[10px] text-[#9AA3B2]">BATTERY LEVEL</div>
                <div className="font-mono-tech text-lg font-bold text-[#00E676]">
                  {telemetry.batteryLevel !== null ? `${telemetry.batteryLevel}%` : 'Android Battery API'}
                </div>
              </div>
              <div className="bg-[#11141E] p-3 rounded-lg border border-white/5">
                <div className="text-[10px] text-[#9AA3B2]">POWER STATE</div>
                <div className="font-mono-tech text-sm font-bold text-white mt-1">
                  {telemetry.batteryCharging === null
                    ? 'Discharging / Normal'
                    : telemetry.batteryCharging
                    ? 'CHARGING (Unplug to game)'
                    : 'ON BATTERY (Optimal)'}
                </div>
              </div>
            </div>
          </div>
        );

      case 'launcher_modal':
        return (
          <div className="bg-[#0A0C12] rounded-xl p-3.5 border border-[#FF1E2D]/40 text-center">
            <p className="text-xs text-[#9AA3B2] mb-3">
              Ready to launch Free Fire directly with your active DARK ALPHA optimization profile.
            </p>
            <button
              type="button"
              onClick={() => {
                onClose();
                onTriggerLaunch();
              }}
              className="w-full py-3 rounded-xl bg-[#FF1E2D] text-white font-display font-bold text-sm uppercase tracking-wider cursor-pointer"
            >
              Launch Free Fire Now
            </button>
          </div>
        );

      case 'bg_apps_checklist':
        return <BackgroundAppsChecklist />;

      case 'sensitivity_studio':
        return (
          <div className="bg-[#0A0C12] rounded-xl p-3.5 border border-[#FF1E2D]/40 flex items-center justify-between gap-3">
            <div>
              <div className="text-xs font-display font-bold text-white">
                Interactive 0–200 Sensitivity Sliders
              </div>
              <div className="text-[11px] text-[#9AA3B2]">
                Tune General, Red Dot, 2X, 4X, Sniper & Free Look in Sensitivity Studio.
              </div>
            </div>
            <button
              type="button"
              onClick={() => {
                onClose();
                onJumpToSensitivity();
              }}
              className="px-3.5 py-2 rounded-lg bg-[#FF1E2D] text-white font-display text-xs font-bold uppercase shrink-0 cursor-pointer"
            >
              Open Studio
            </button>
          </div>
        );

      case 'dpi_calculator':
        return (
          <DpiSafeCalculator
            screenWidth={telemetry.screenWidth}
            dpr={telemetry.devicePixelRatio}
          />
        );

      case 'hud_visualizer':
        return <HudLayoutVisualizer />;

      case 'storage_live':
        return (
          <div className="bg-[#0A0C12] rounded-xl p-3.5 border border-white/10">
            <div className="flex items-center gap-2 text-xs font-display font-bold uppercase text-white mb-2">
              <HardDrive className="w-4 h-4 text-[#00D4FF]" />
              <span>Real Storage Quota Telemetry</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="bg-[#11141E] p-3 rounded-lg border border-white/5">
                <div className="text-[10px] text-[#9AA3B2]">APP CACHE QUOTA</div>
                <div className="font-mono-tech text-base font-bold text-white">
                  {telemetry.storageQuotaMb !== null
                    ? `${(telemetry.storageQuotaMb / 1024).toFixed(1)} GB`
                    : 'Available'}
                </div>
              </div>
              <div className="bg-[#11141E] p-3 rounded-lg border border-white/5">
                <div className="text-[10px] text-[#9AA3B2]">ACTIVE CACHE USED</div>
                <div className="font-mono-tech text-base font-bold text-[#00E676]">
                  {telemetry.storageUsedMb !== null ? `${telemetry.storageUsedMb} MB` : '0 MB'}
                </div>
              </div>
            </div>
          </div>
        );

      case 'touch_test':
        return <TouchScreenTester />;

      case 'brightness_test':
        return (
          <div className="bg-[#0A0C12] rounded-xl p-3.5 border border-white/10">
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="text-white font-display font-bold uppercase flex items-center gap-1.5">
                <Sun className="w-4 h-4 text-[#FF9F1C]" />
                <span>Contrast & Visibility Preview</span>
              </span>
              <span className="font-mono-tech text-[#FF9F1C]">{testBrightness}%</span>
            </div>
            <input
              type="range"
              min={20}
              max={100}
              value={testBrightness}
              onChange={(e) => setTestBrightness(Number(e.target.value))}
              className="w-full alpha-slider mb-3"
            />
            <div
              style={{ opacity: testBrightness / 100 }}
              className="p-3 rounded-lg bg-[#161B28] border border-white/15 flex items-center justify-between text-xs"
            >
              <span>Shadow Silhouette Visibility Check</span>
              <span className="px-2 py-0.5 rounded bg-[#FF1E2D] text-white font-mono-tech text-[10px]">
                TARGET
              </span>
            </div>
          </div>
        );

      case 'network_speed_test':
        return (
          <div className="bg-[#0A0C12] rounded-xl p-3.5 border border-white/10">
            <div className="flex items-center justify-between mb-2.5">
              <span className="text-xs font-display font-bold uppercase text-white flex items-center gap-1.5">
                <Wifi className="w-4 h-4 text-[#00D4FF]" />
                <span>Live Ping & Throughput Probe</span>
              </span>
              <span className="font-mono-tech text-[11px] uppercase text-[#00E676]">
                {telemetry.online ? `${telemetry.effectiveType.toUpperCase()} ONLINE` : 'OFFLINE'}
              </span>
            </div>

            {speedTest && (
              <div className="grid grid-cols-3 gap-2 mb-3 text-center">
                <div className="bg-[#11141E] p-2.5 rounded-lg border border-white/5">
                  <div className="text-[10px] text-[#9AA3B2]">PING</div>
                  <div className="font-mono-tech text-base font-bold text-[#00E676]">
                    {speedTest.pingMs}ms
                  </div>
                </div>
                <div className="bg-[#11141E] p-2.5 rounded-lg border border-white/5">
                  <div className="text-[10px] text-[#9AA3B2]">JITTER</div>
                  <div className="font-mono-tech text-base font-bold text-white">
                    {speedTest.jitterMs}ms
                  </div>
                </div>
                <div className="bg-[#11141E] p-2.5 rounded-lg border border-white/5">
                  <div className="text-[10px] text-[#9AA3B2]">DOWNLINK</div>
                  <div className="font-mono-tech text-base font-bold text-[#00D4FF]">
                    {speedTest.downloadMbps} Mbps
                  </div>
                </div>
              </div>
            )}

            <button
              type="button"
              disabled={isTestingSpeed}
              onClick={() => onRunSpeedTest()}
              className="w-full py-2.5 rounded-lg bg-[#FF1E2D] hover:brightness-110 disabled:opacity-50 text-white font-display text-xs font-bold uppercase tracking-wider cursor-pointer"
            >
              {isTestingSpeed ? 'Measuring Real Latency...' : 'Run Live Network Benchmark'}
            </button>
          </div>
        );

      case 'data_calculator':
        return <DataUsageCalculator />;

      case 'gaming_timer':
        return <GamingSessionTimer />;

      case 'audio_pan_test':
        return <AudioPanTester />;

      case 'troubleshooter':
        return <TroubleshootingMatrix />;

      case 'quick_device_check':
        return (
          <div className="bg-[#0A0C12] rounded-xl p-3.5 border border-white/10">
            <button
              type="button"
              onClick={() => {
                setScanComplete(true);
                onLogHistory(
                  'Quick 5-Point Device Check',
                  `FPS ${telemetry.fps} | Cores ${telemetry.cpuCores ?? 'N/A'} | Online: ${telemetry.online}`,
                  'diagnostic'
                );
              }}
              className="w-full py-2.5 rounded-lg bg-[#FF1E2D] text-white font-display text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer"
            >
              <Play className="w-3.5 h-3.5" />
              <span>Run 5-Point Hardware Readiness Scan</span>
            </button>

            {scanComplete && (
              <div className="mt-3 space-y-1.5 text-xs">
                <div className="flex justify-between p-2 rounded bg-[#11141E]">
                  <span className="text-[#9AA3B2]">1. Render Frame Cadence</span>
                  <span className="font-mono-tech text-[#00E676] font-bold">
                    PASS ({telemetry.fps} FPS)
                  </span>
                </div>
                <div className="flex justify-between p-2 rounded bg-[#11141E]">
                  <span className="text-[#9AA3B2]">2. CPU Multi-Core Check</span>
                  <span className="font-mono-tech text-[#00E676] font-bold">
                    PASS ({telemetry.cpuCores ?? 'Multi'} Cores)
                  </span>
                </div>
                <div className="flex justify-between p-2 rounded bg-[#11141E]">
                  <span className="text-[#9AA3B2]">3. RAM Tier Recommendation</span>
                  <span className="font-mono-tech text-white font-bold">
                    {telemetry.deviceMemoryGb
                      ? `${telemetry.deviceMemoryGb}GB (${
                          telemetry.deviceMemoryGb <= 2 ? 'Use 2GB Ultra-Lite' : 'Balanced'
                        })`
                      : '2GB Ultra-Lite Safe'}
                  </span>
                </div>
                <div className="flex justify-between p-2 rounded bg-[#11141E]">
                  <span className="text-[#9AA3B2]">4. Power & Voltage State</span>
                  <span className="font-mono-tech text-[#00E676] font-bold">
                    {telemetry.batteryLevel !== null ? `${telemetry.batteryLevel}% READY` : 'READY'}
                  </span>
                </div>
                <div className="flex justify-between p-2 rounded bg-[#11141E]">
                  <span className="text-[#9AA3B2]">5. Network Socket</span>
                  <span className="font-mono-tech text-[#00E676] font-bold">
                    {telemetry.online ? 'CONNECTED' : 'OFFLINE'}
                  </span>
                </div>
              </div>
            )}
          </div>
        );

      case 'device_info_live':
        return (
          <div className="bg-[#0A0C12] rounded-xl p-3.5 border border-white/10 space-y-1.5 text-xs">
            <div className="flex justify-between py-1 border-b border-white/5">
              <span className="text-[#9AA3B2]">Platform / OS</span>
              <span className="font-mono-tech text-white">{telemetry.platform}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-white/5">
              <span className="text-[#9AA3B2]">Screen Resolution</span>
              <span className="font-mono-tech text-white">
                {telemetry.screenWidth} × {telemetry.screenHeight} ({telemetry.devicePixelRatio}x DPR)
              </span>
            </div>
            <div className="flex justify-between py-1 border-b border-white/5">
              <span className="text-[#9AA3B2]">CPU Logical Cores</span>
              <span className="font-mono-tech text-[#00E676]">
                {telemetry.cpuCores ?? 'Android Native'}
              </span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-[#9AA3B2]">Detected Memory</span>
              <span className="font-mono-tech text-white">
                {telemetry.deviceMemoryGb ? `${telemetry.deviceMemoryGb} GB` : 'Android Native'}
              </span>
            </div>
          </div>
        );

      case 'custom_profiles':
        return (
          <div className="bg-[#0A0C12] rounded-xl p-3.5 border border-white/10 space-y-3">
            <form onSubmit={handleCreateProfile} className="space-y-2">
              <input
                type="text"
                value={profName}
                onChange={(e) => setProfName(e.target.value)}
                placeholder="Profile Name (e.g., BR Ranked 2GB Safe)"
                className="w-full bg-[#11141E] border border-white/10 rounded-lg px-3 py-2 text-xs text-white"
              />
              <div className="grid grid-cols-2 gap-2">
                <select
                  value={profPkg}
                  onChange={(e) => setProfPkg(e.target.value as FFPackageType)}
                  className="bg-[#11141E] border border-white/10 rounded-lg px-2.5 py-2 text-xs text-white"
                >
                  <option value="com.dts.freefireth">Free Fire (Standard)</option>
                  <option value="com.dts.freefiremax">Free Fire MAX</option>
                </select>
                <select
                  value={profMode}
                  onChange={(e) => setProfMode(e.target.value as PerformancePreset)}
                  className="bg-[#11141E] border border-white/10 rounded-lg px-2.5 py-2 text-xs text-white"
                >
                  <option value="ultra_2gb">2GB Ultra-Lite</option>
                  <option value="balanced">Balanced Smooth</option>
                  <option value="esports_max">Esports Max</option>
                </select>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <select
                  value={profGfx}
                  onChange={(e) => setProfGfx(e.target.value as any)}
                  className="bg-[#11141E] border border-white/10 rounded-lg px-2.5 py-2 text-xs text-white"
                >
                  <option value="Smooth">Graphics: Smooth</option>
                  <option value="Standard">Graphics: Standard</option>
                  <option value="Ultra">Graphics: Ultra</option>
                </select>
                <select
                  value={profFps}
                  onChange={(e) => setProfFps(e.target.value as any)}
                  className="bg-[#11141E] border border-white/10 rounded-lg px-2.5 py-2 text-xs text-white"
                >
                  <option value="Normal (30)">FPS: Normal</option>
                  <option value="High (60)">FPS: High</option>
                </select>
              </div>
              <button
                type="submit"
                className="w-full py-2 rounded-lg bg-[#FF1E2D] text-white font-display text-xs font-bold uppercase flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Create Custom Profile</span>
              </button>
            </form>

            {customProfiles.length > 0 && (
              <div className="space-y-1.5 pt-2 border-t border-white/10">
                {customProfiles.map((p) => (
                  <div
                    key={p.id}
                    className="flex items-center justify-between p-2.5 rounded-lg bg-[#11141E] border border-white/5"
                  >
                    <div>
                      <div className="text-xs font-bold text-white">{p.name}</div>
                      <div className="text-[10px] text-[#9AA3B2]">
                        {p.graphicsPreset} • {p.fpsTarget} • {p.perfMode}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        onApplyCustomProfile(p);
                        onClose();
                      }}
                      className="px-2.5 py-1 rounded bg-[#00E676]/20 text-[#00E676] font-display text-[11px] font-bold uppercase cursor-pointer"
                    >
                      Activate
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        );

      case 'history_log':
        return (
          <div className="bg-[#0A0C12] rounded-xl p-3.5 border border-white/10">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-display font-bold uppercase text-white">
                Recorded Session Events ({historyLog.length})
              </span>
              {historyLog.length > 0 && (
                <button
                  type="button"
                  onClick={onClearHistory}
                  className="inline-flex items-center gap-1 text-[11px] text-[#FF1E2D] hover:underline cursor-pointer"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>Clear</span>
                </button>
              )}
            </div>
            {historyLog.length === 0 ? (
              <p className="text-xs text-[#5C6475] py-3 text-center">
                No actions recorded yet. Run a Speed Test, Quick Check, or Launch Free Fire.
              </p>
            ) : (
              <div className="max-h-48 overflow-y-auto space-y-1.5 pr-1">
                {historyLog.map((item) => (
                  <div
                    key={item.id}
                    className="p-2 rounded-lg bg-[#11141E] border border-white/5 text-xs"
                  >
                    <div className="flex justify-between">
                      <span className="font-semibold text-white">{item.action}</span>
                      <span className="font-mono-tech text-[10px] text-[#5C6475]">
                        {item.timestamp}
                      </span>
                    </div>
                    <div className="text-[11px] text-[#9AA3B2] mt-0.5">{item.detail}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        );

      case 'about_flutter':
        return (
          <div className="bg-[#0A0C12] rounded-xl p-3.5 border border-[#FF1E2D]/40 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="font-display font-bold text-sm text-white">
                DARK ALPHA FF OPTIMIZER v1.0
              </span>
              <span className="font-mono-tech text-[10px] px-2 py-0.5 rounded bg-[#00E676]/15 text-[#00E676]">
                FAIR-PLAY VERIFIED
              </span>
            </div>
            <p className="text-xs text-[#9AA3B2] leading-relaxed">
              Engineered for low-end 2GB RAM Android smartphones. Zero game file modification, zero
              fake telemetry, and full native Flutter Android source code included.
            </p>
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenFlutterModal();
              }}
              className="w-full py-2.5 rounded-lg bg-[#FF1E2D] text-white font-display text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer"
            >
              <Code2 className="w-4 h-4" />
              <span>Open Flutter Android Source Code Studio</span>
            </button>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/80 p-0 sm:p-4">
      <div className="w-full max-w-[500px] max-h-[90vh] overflow-y-auto rounded-t-2xl sm:rounded-2xl bg-[#0E1016] border border-[#FF1E2D]/45 p-4 sm:p-5 shadow-2xl">
        {/* Header */}
        <div className="flex items-start justify-between gap-3 pb-3 border-b border-white/10">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono-tech text-xs font-bold px-2 py-0.5 rounded bg-[#FF1E2D]/20 text-[#FF1E2D]">
                #{feature.code}
              </span>
              <span className="font-mono-tech text-[10px] uppercase tracking-wider text-[#9AA3B2]">
                {feature.tag}
              </span>
            </div>
            <h2 className="font-display font-bold text-lg text-white mt-1">{feature.title}</h2>
            <p className="text-xs text-[#9AA3B2]">{feature.titleSi}</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close modal"
            className="p-2 rounded-lg bg-[#151822] text-[#9AA3B2] hover:text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-4 mt-4">
          {/* Interactive Tool Area */}
          {renderInteractiveWidget()}

          {/* Android Intent Shortcut Button (if available) */}
          {feature.androidIntentAction && (
            <div>
              <button
                type="button"
                onClick={() =>
                  handleOpenAndroidIntent(
                    feature.androidIntentAction!,
                    feature.androidIntentLabel || feature.title
                  )
                }
                className="w-full py-2.5 px-4 rounded-xl bg-[#151822] hover:bg-[#1C202E] border border-[#00D4FF]/40 text-[#00D4FF] font-display text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>{feature.androidIntentLabel || 'Open Android System Setting'}</span>
              </button>
              {intentNotice && (
                <p className="text-[11px] text-[#00E676] mt-1.5 text-center">{intentNotice}</p>
              )}
            </div>
          )}

          {/* Actionable Optimization Steps */}
          <div className="bg-[#0A0C12] rounded-xl p-3.5 border border-white/10">
            <h3 className="font-display font-bold text-xs uppercase tracking-wider text-white mb-2.5">
              Optimization Protocol
            </h3>
            <ol className="space-y-2">
              {feature.steps.map((step, idx) => (
                <li key={idx} className="flex items-start gap-2.5 text-xs text-[#F4F6FA]">
                  <span className="font-mono-tech text-[11px] font-bold text-[#FF1E2D] mt-0.5">
                    0{idx + 1}
                  </span>
                  <span className="leading-relaxed">{step}</span>
                </li>
              ))}
            </ol>
          </div>

          {/* Pro Tip */}
          <div className="p-3 rounded-xl bg-[#FF9F1C]/10 border border-[#FF9F1C]/30 flex items-start gap-2.5 text-xs">
            <Lightbulb className="w-4 h-4 text-[#FF9F1C] shrink-0 mt-0.5" />
            <div>
              <span className="font-bold text-[#FF9F1C]">DARK ALPHA PRO TIP: </span>
              <span className="text-[#F4F6FA]">{feature.proTip}</span>
            </div>
          </div>

          {/* Fair-Play Compliance Note */}
          <div className="flex items-center justify-between pt-2 border-t border-white/10">
            <span className="inline-flex items-center gap-1.5 text-[11px] text-[#00E676]">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>{feature.fairPlayNote || 'Safe • No Game File Tampering'}</span>
            </span>

            <button
              type="button"
              onClick={() => {
                onLogHistory(`Applied #${feature.code} ${feature.title}`, feature.tag, 'system');
                onClose();
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#00E676]/15 hover:bg-[#00E676]/25 text-[#00E676] font-display text-xs font-bold uppercase cursor-pointer"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Done</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
