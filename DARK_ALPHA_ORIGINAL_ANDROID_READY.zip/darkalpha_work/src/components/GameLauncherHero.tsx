import React, { useState } from 'react';
import {
  Rocket,
  ShieldCheck,
  CheckCircle2,
  Circle,
  Zap,
  Flame,
  Smartphone,
  ExternalLink,
  Code2,
} from 'lucide-react';
import { FFPackageType, PerformancePreset } from '../types/optimizer';

interface GameLauncherHeroProps {
  selectedPackage: FFPackageType;
  onSelectPackage: (pkg: FFPackageType) => void;
  gamingMode: boolean;
  onToggleGamingMode: () => void;
  lowRamMode: boolean;
  onToggleLowRamMode: () => void;
  perfPreset: PerformancePreset;
  onSelectPerfPreset: (preset: PerformancePreset) => void;
  isAndroid: boolean;
  lang: 'en' | 'si';
  onLaunchGame: (pkg: FFPackageType) => void;
  onOpenFlutterModal: () => void;
  pingMs: number | null;
}

export const GameLauncherHero: React.FC<GameLauncherHeroProps> = ({
  selectedPackage,
  onSelectPackage,
  gamingMode,
  onToggleGamingMode,
  lowRamMode,
  onToggleLowRamMode,
  perfPreset,
  onSelectPerfPreset,
  isAndroid,
  lang,
  onLaunchGame,
  onOpenFlutterModal,
  pingMs,
}) => {
  const [bgAppsClosed, setBgAppsClosed] = useState(false);
  const [dndEnabled, setDndEnabled] = useState(false);
  const [launchState, setLaunchState] = useState<'idle' | 'preparing' | 'launched'>('idle');

  const checklist = [
    {
      id: 'low_ram',
      label: lang === 'si' ? '2GB RAM සැහැල්ලු මාදිලිය' : 'Low RAM UI Overhead Mode',
      checked: lowRamMode,
      toggle: onToggleLowRamMode,
    },
    {
      id: 'bg_apps',
      label: lang === 'si' ? 'පසුබිම් Apps වසා ඇත' : 'Background Social Apps Closed',
      checked: bgAppsClosed,
      toggle: () => setBgAppsClosed((p) => !p),
    },
    {
      id: 'dnd',
      label: lang === 'si' ? 'Do Not Disturb (Calls අවහිර)' : 'Do Not Disturb / Alerts Silenced',
      checked: dndEnabled,
      toggle: () => setDndEnabled((p) => !p),
    },
    {
      id: 'net',
      label:
        pingMs !== null
          ? `Network Verified (${pingMs}ms)`
          : lang === 'si'
          ? 'Network සම්බන්ධතාවය සූදානම්'
          : 'Network Connection Active',
      checked: true,
      toggle: () => {},
    },
  ];

  const readyCount = checklist.filter((c) => c.checked).length;

  const handleLaunchClick = () => {
    setLaunchState('preparing');
    onLaunchGame(selectedPackage);

    // Attempt direct Android package intent trigger on Android browsers / WebView
    const androidIntentUri = `intent:#Intent;package=${selectedPackage};action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;end`;
    if (isAndroid) {
      try {
        window.location.href = androidIntentUri;
      } catch {
        // Fallback handled in UI status banner
      }
    }

    setTimeout(() => {
      setLaunchState('launched');
    }, 650);

    setTimeout(() => {
      setLaunchState('idle');
    }, 5500);
  };

  return (
    <section className="relative overflow-hidden rounded-2xl card-surface neon-crimson-border p-4 sm:p-5">
      {/* Subtle top crimson accent line */}
      <div className="absolute inset-x-0 top-0 h-[2px] bg-gradient-to-r from-transparent via-[#FF1E2D] to-transparent" />

      {/* Top Row: Gaming Mode & Fair-Play Pill */}
      <div className="flex flex-wrap items-center justify-between gap-2 mb-3.5">
        <button
          onClick={onToggleGamingMode}
          className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-display font-bold uppercase tracking-wider transition-all cursor-pointer ${
            gamingMode
              ? 'bg-[#FF1E2D]/20 text-[#FF1E2D] border border-[#FF1E2D]/50'
              : 'bg-[#151822] text-[#9AA3B2] border border-white/10'
          }`}
        >
          <Flame className={`w-3.5 h-3.5 ${gamingMode ? 'text-[#FF1E2D]' : 'text-[#5C6475]'}`} />
          <span>{gamingMode ? 'GAMING MODE: ACTIVE' : 'GAMING MODE: STANDBY'}</span>
        </button>

        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#00E676]/10 border border-[#00E676]/30 text-[11px] font-medium text-[#00E676]">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>ANTI-BAN • ZERO FILE MOD</span>
        </span>
      </div>

      {/* Client Selector: Free Fire vs Free Fire MAX */}
      <div className="mb-3.5">
        <div className="flex items-center justify-between text-[11px] text-[#9AA3B2] mb-1.5">
          <span className="uppercase tracking-wider font-semibold">
            {lang === 'si' ? 'ක්‍රීඩා පැකේජය තෝරන්න (Select Client)' : 'TARGET GAME PACKAGE (#09)'}
          </span>
          <span className="font-mono-tech text-[#5C6475]">{selectedPackage}</span>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => onSelectPackage('com.dts.freefireth')}
            className={`flex items-center justify-between px-3 py-2.5 rounded-xl border text-left transition-all cursor-pointer ${
              selectedPackage === 'com.dts.freefireth'
                ? 'bg-[#FF1E2D]/15 border-[#FF1E2D] text-white'
                : 'bg-[#12151E] border-white/10 text-[#9AA3B2] hover:border-white/25'
            }`}
          >
            <div>
              <div className="font-display font-bold text-sm tracking-wide">FREE FIRE</div>
              <div className="text-[10px] text-[#9AA3B2]">2GB RAM Recommended</div>
            </div>
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                selectedPackage === 'com.dts.freefireth' ? 'bg-[#FF1E2D]' : 'bg-white/15'
              }`}
            />
          </button>

          <button
            type="button"
            onClick={() => onSelectPackage('com.dts.freefiremax')}
            className={`flex items-center justify-between px-3 py-2.5 rounded-xl border text-left transition-all cursor-pointer ${
              selectedPackage === 'com.dts.freefiremax'
                ? 'bg-[#FF1E2D]/15 border-[#FF1E2D] text-white'
                : 'bg-[#12151E] border-white/10 text-[#9AA3B2] hover:border-white/25'
            }`}
          >
            <div>
              <div className="font-display font-bold text-sm tracking-wide">FREE FIRE MAX</div>
              <div className="text-[10px] text-[#9AA3B2]">HD Textures Client</div>
            </div>
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                selectedPackage === 'com.dts.freefiremax' ? 'bg-[#FF1E2D]' : 'bg-white/15'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Performance Mode Selector (#02) */}
      <div className="mb-4">
        <div className="flex items-center justify-between text-[11px] text-[#9AA3B2] mb-1.5">
          <span className="uppercase tracking-wider font-semibold">
            {lang === 'si' ? 'ක්‍රියාකාරීත්ව මාදිලිය (#02)' : 'PERFORMANCE PROFILE (#02)'}
          </span>
          <span className="text-[#FF1E2D] font-mono-tech text-[11px]">
            {perfPreset === 'ultra_2gb'
              ? '2GB ULTRA-LITE'
              : perfPreset === 'balanced'
              ? 'BALANCED'
              : 'ESPORTS MAX'}
          </span>
        </div>
        <div className="grid grid-cols-3 gap-1.5 bg-[#090B10] p-1 rounded-xl border border-white/10">
          {[
            { id: 'ultra_2gb' as PerformancePreset, label: '2GB Ultra-Lite', sub: 'Low RAM' },
            { id: 'balanced' as PerformancePreset, label: 'Balanced', sub: 'Smooth' },
            { id: 'esports_max' as PerformancePreset, label: 'Esports Max', sub: 'High Hz' },
          ].map((mode) => (
            <button
              key={mode.id}
              type="button"
              onClick={() => onSelectPerfPreset(mode.id)}
              className={`py-2 px-2 rounded-lg text-center transition-all cursor-pointer ${
                perfPreset === mode.id
                  ? 'bg-[#FF1E2D] text-white font-bold'
                  : 'text-[#9AA3B2] hover:text-white'
              }`}
            >
              <div className="font-display text-xs tracking-wide">{mode.label}</div>
              <div
                className={`text-[10px] ${
                  perfPreset === mode.id ? 'text-white/90' : 'text-[#5C6475]'
                }`}
              >
                {mode.sub}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Pre-Flight Readiness Checklist */}
      <div className="mb-4 bg-[#0A0C12] rounded-xl p-3 border border-white/10">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] font-display uppercase tracking-wider text-[#9AA3B2]">
            {lang === 'si'
              ? 'ක්‍රීඩාවට පෙර සූදානම් පරීක්ෂාව'
              : 'PRE-LAUNCH READINESS CHECKLIST'}
          </span>
          <span className="font-mono-tech text-xs font-bold text-[#00E676]">
            {readyCount}/4 READY
          </span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
          {checklist.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={item.toggle}
              className="flex items-center gap-2 text-left px-2.5 py-1.5 rounded-lg bg-[#11141E] hover:bg-[#161A26] border border-white/5 transition-colors cursor-pointer"
            >
              {item.checked ? (
                <CheckCircle2 className="w-4 h-4 text-[#00E676] shrink-0" />
              ) : (
                <Circle className="w-4 h-4 text-[#5C6475] shrink-0" />
              )}
              <span
                className={`text-xs truncate ${
                  item.checked ? 'text-[#F4F6FA]' : 'text-[#9AA3B2]'
                }`}
              >
                {item.label}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* PRIMARY HERO CTA: FF LAUNCH BUTTON */}
      <button
        type="button"
        onClick={handleLaunchClick}
        className="w-full relative group overflow-hidden rounded-xl bg-gradient-to-r from-[#D90429] via-[#FF1E2D] to-[#FF3B47] hover:brightness-110 active:scale-[0.99] text-white py-4 px-5 neon-crimson-glow transition-all cursor-pointer"
      >
        <div className="flex items-center justify-center gap-3">
          <Rocket className="w-5 h-5 text-white shrink-0" />
          <div className="text-left">
            <div className="font-display font-bold text-base sm:text-lg tracking-[0.1em] uppercase leading-tight">
              {launchState === 'preparing'
                ? lang === 'si'
                  ? 'ක්‍රීඩාව සූදානම් කරමින්...'
                  : 'INITIALIZING LAUNCH INTENT...'
                : selectedPackage === 'com.dts.freefiremax'
                ? 'LAUNCH FREE FIRE MAX'
                : 'LAUNCH FREE FIRE'}
            </div>
            <div className="text-[11px] text-white/85 font-medium">
              {lang === 'si'
                ? 'එබූ විගස කෙලින්ම Free Fire ඇතුළට පිවිසෙන්න'
                : `Direct Android Package Intent • ${selectedPackage}`}
            </div>
          </div>
          <ExternalLink className="w-4 h-4 text-white/80 ml-auto shrink-0" />
        </div>
      </button>

      {/* Launch Feedback Banner */}
      {launchState === 'launched' && (
        <div className="mt-3 p-3 rounded-xl bg-[#00E676]/10 border border-[#00E676]/35 text-xs text-[#F4F6FA]">
          <div className="flex items-start gap-2">
            <Zap className="w-4 h-4 text-[#00E676] shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-[#00E676]">
                {isAndroid
                  ? `Android Launch Intent Dispatched (${selectedPackage})`
                  : `Launch Sequence Triggered for ${selectedPackage}`}
              </p>
              <p className="text-[#9AA3B2] mt-1 leading-relaxed">
                {isAndroid
                  ? 'If Free Fire is installed, Android opens it immediately. For native APK one-tap launch without browser prompts, export the Flutter APK below.'
                  : 'You are viewing on a desktop/non-Android browser. On an Android phone, this triggers the native package intent—or grab the complete Flutter Android APK code below.'}
              </p>
              <button
                type="button"
                onClick={onOpenFlutterModal}
                className="mt-2 inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#FF1E2D] text-white font-display font-bold text-[11px] uppercase tracking-wider cursor-pointer"
              >
                <Code2 className="w-3.5 h-3.5" />
                <span>Get Flutter Android APK Code</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Subtle Android device status footer */}
      <div className="mt-3 pt-2.5 border-t border-white/5 flex items-center justify-between text-[11px] text-[#5C6475]">
        <span className="inline-flex items-center gap-1.5">
          <Smartphone className="w-3.5 h-3.5 text-[#9AA3B2]" />
          <span>{isAndroid ? 'Android Runtime Detected' : 'Web Preview + Flutter APK Ready'}</span>
        </span>
        <button
          type="button"
          onClick={onOpenFlutterModal}
          className="text-[#FF1E2D] hover:underline font-medium cursor-pointer"
        >
          Flutter Source →
        </button>
      </div>
    </section>
  );
};
