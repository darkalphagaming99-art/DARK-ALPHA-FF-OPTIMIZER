import React, { useState, useRef, useEffect } from 'react';
import {
  Fingerprint,
  Volume2,
  Play,
  Pause,
  RotateCcw,
  AlertTriangle,
  CheckCircle2,
  Smartphone,
  Sliders,
} from 'lucide-react';

// #23 Touch Screen Multi-Touch & Latency Tester
export const TouchScreenTester: React.FC = () => {
  const [touches, setTouches] = useState<{ id: number; x: number; y: number }[]>([]);
  const [maxFingers, setMaxFingers] = useState(0);
  const [lastLatencyMs, setLastLatencyMs] = useState<number | null>(null);
  const lastEventTimeRef = useRef<number>(performance.now());
  const boxRef = useRef<HTMLDivElement | null>(null);

  const handleTouchUpdate = (e: React.TouchEvent<HTMLDivElement>) => {
    e.preventDefault();
    const now = performance.now();
    const delta = Math.max(1, Math.round(now - lastEventTimeRef.current));
    if (delta < 250) {
      setLastLatencyMs(delta);
    }
    lastEventTimeRef.current = now;

    const rect = boxRef.current?.getBoundingClientRect();
    if (!rect) return;

    const active = Array.from(e.touches).map((t) => ({
      id: t.identifier,
      x: Math.round(t.clientX - rect.left),
      y: Math.round(t.clientY - rect.top),
    }));

    setTouches(active);
    setMaxFingers((prev) => Math.max(prev, active.length));
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerType === 'touch') return;
    const rect = boxRef.current?.getBoundingClientRect();
    if (!rect) return;
    const now = performance.now();
    setLastLatencyMs(Math.max(1, Math.round(now - lastEventTimeRef.current)));
    lastEventTimeRef.current = now;
    setTouches([
      {
        id: e.pointerId,
        x: Math.round(e.clientX - rect.left),
        y: Math.round(e.clientY - rect.top),
      },
    ]);
    setMaxFingers((prev) => Math.max(prev, 1));
  };

  return (
    <div className="bg-[#0A0C12] rounded-xl p-3.5 border border-white/10">
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs font-display font-bold uppercase text-white flex items-center gap-1.5">
          <Fingerprint className="w-4 h-4 text-[#FF1E2D]" />
          <span>Multi-Touch & Claw Panel</span>
        </span>
        <button
          type="button"
          onClick={() => {
            setTouches([]);
            setMaxFingers(0);
            setLastLatencyMs(null);
          }}
          className="text-[11px] text-[#9AA3B2] hover:text-white underline cursor-pointer"
        >
          Reset
        </button>
      </div>

      <div
        ref={boxRef}
        onTouchStart={handleTouchUpdate}
        onTouchMove={handleTouchUpdate}
        onTouchEnd={handleTouchUpdate}
        onPointerDown={handlePointerDown}
        onPointerUp={() => setTouches([])}
        className="relative h-44 w-full rounded-xl bg-[#060609] border border-dashed border-[#FF1E2D]/45 overflow-hidden select-none touch-none flex items-center justify-center"
      >
        {touches.length === 0 ? (
          <div className="text-center px-4 pointer-events-none">
            <p className="text-xs font-display uppercase tracking-wider text-[#9AA3B2]">
              Place 2, 3, or 4 Fingers Here
            </p>
            <p className="text-[11px] text-[#5C6475] mt-1">
              Tests multi-touch claw grip & touch sampling interval
            </p>
          </div>
        ) : null}

        {touches.map((t, idx) => (
          <div
            key={t.id}
            style={{ left: t.x - 24, top: t.y - 24 }}
            className="absolute w-12 h-12 rounded-full border-2 border-[#FF1E2D] bg-[#FF1E2D]/25 flex items-center justify-center pointer-events-none"
          >
            <span className="font-mono-tech text-[11px] font-bold text-white">F{idx + 1}</span>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-2 mt-2.5 text-center">
        <div className="bg-[#11141E] rounded-lg p-2 border border-white/5">
          <div className="text-[10px] text-[#9AA3B2]">ACTIVE TOUCHES</div>
          <div className="font-mono-tech text-sm font-bold text-white">{touches.length}</div>
        </div>
        <div className="bg-[#11141E] rounded-lg p-2 border border-white/5">
          <div className="text-[10px] text-[#9AA3B2]">MAX CLAW FINGERS</div>
          <div className="font-mono-tech text-sm font-bold text-[#00E676]">{maxFingers}F</div>
        </div>
        <div className="bg-[#11141E] rounded-lg p-2 border border-white/5">
          <div className="text-[10px] text-[#9AA3B2]">SAMPLE DELTA</div>
          <div className="font-mono-tech text-sm font-bold text-[#00D4FF]">
            {lastLatencyMs !== null ? `${lastLatencyMs}ms` : '--'}
          </div>
        </div>
      </div>
    </div>
  );
};

// #18 Interactive Free Fire HUD Layout Visualizer
export const HudLayoutVisualizer: React.FC = () => {
  const [grip, setGrip] = useState<'2f' | '3f' | '4f'>('3f');

  const layouts = {
    '2f': {
      title: '2-Finger Classic Thumb HUD',
      desc: 'Ideal for 2GB RAM compact screens (5.5"–6.2"). Right thumb handles fire + jump + crouch; left thumb controls joystick + gloo wall.',
      buttons: [
        { label: 'JOYSTICK', x: '14%', y: '72%', size: 'w-14 h-14', color: 'border-white/40' },
        { label: 'GLOO', x: '26%', y: '48%', size: 'w-10 h-10', color: 'border-[#00D4FF]' },
        { label: 'FIRE 46%', x: '84%', y: '68%', size: 'w-14 h-14', color: 'border-[#FF1E2D] bg-[#FF1E2D]/25' },
        { label: 'SCOPE', x: '88%', y: '42%', size: 'w-10 h-10', color: 'border-white/40' },
        { label: 'JUMP', x: '74%', y: '46%', size: 'w-9 h-9', color: 'border-white/40' },
        { label: 'CROUCH', x: '72%', y: '76%', size: 'w-9 h-9', color: 'border-[#00E676]' },
      ],
    },
    '3f': {
      title: '3-Finger Sit-Up Gloo Claw',
      desc: 'Left index finger sits at top-left for Left Fire / Gloo Wall deploy while right thumb aims and drags smoothly.',
      buttons: [
        { label: 'L-FIRE', x: '13%', y: '20%', size: 'w-12 h-12', color: 'border-[#FF1E2D] bg-[#FF1E2D]/25' },
        { label: 'JOYSTICK', x: '15%', y: '72%', size: 'w-14 h-14', color: 'border-white/40' },
        { label: 'GLOO', x: '24%', y: '45%', size: 'w-10 h-10', color: 'border-[#00D4FF]' },
        { label: 'R-FIRE 45%', x: '85%', y: '68%', size: 'w-14 h-14', color: 'border-[#FF1E2D] bg-[#FF1E2D]/25' },
        { label: 'JUMP', x: '75%', y: '44%', size: 'w-10 h-10', color: 'border-white/40' },
        { label: 'CROUCH', x: '72%', y: '76%', size: 'w-10 h-10', color: 'border-[#00E676]' },
      ],
    },
    '4f': {
      title: '4-Finger Pro Esports Claw',
      desc: 'Left index handles Left Fire; right index controls Jump + Scope + Quick Weapon Switch for instant AWM/shotgun swaps.',
      buttons: [
        { label: 'L-FIRE', x: '13%', y: '20%', size: 'w-12 h-12', color: 'border-[#FF1E2D] bg-[#FF1E2D]/25' },
        { label: 'JOYSTICK', x: '15%', y: '72%', size: 'w-13 h-13', color: 'border-white/40' },
        { label: 'GLOO', x: '26%', y: '44%', size: 'w-10 h-10', color: 'border-[#00D4FF]' },
        { label: 'JUMP', x: '86%', y: '20%', size: 'w-11 h-11', color: 'border-[#00E676]' },
        { label: 'SCOPE', x: '73%', y: '22%', size: 'w-10 h-10', color: 'border-white/40' },
        { label: 'R-FIRE 44%', x: '85%', y: '70%', size: 'w-14 h-14', color: 'border-[#FF1E2D] bg-[#FF1E2D]/25' },
      ],
    },
  };

  const active = layouts[grip];

  return (
    <div className="bg-[#0A0C12] rounded-xl p-3.5 border border-white/10">
      <div className="flex gap-1.5 mb-3">
        {[
          { id: '2f' as const, label: '2-Finger' },
          { id: '3f' as const, label: '3-Finger Claw' },
          { id: '4f' as const, label: '4-Finger Pro' },
        ].map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setGrip(tab.id)}
            className={`flex-1 py-1.5 rounded-lg font-display text-xs font-bold uppercase cursor-pointer transition-colors ${
              grip === tab.id
                ? 'bg-[#FF1E2D] text-white'
                : 'bg-[#12151E] text-[#9AA3B2] hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Simulated Landscape Phone Viewport */}
      <div className="relative h-44 w-full rounded-xl bg-[#060609] border border-white/15 overflow-hidden">
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-3 h-3 rounded-full border border-[#FF1E2D]/70" />
        </div>
        {active.buttons.map((btn) => (
          <div
            key={btn.label}
            style={{ left: btn.x, top: btn.y, transform: 'translate(-50%, -50%)' }}
            className={`absolute ${btn.size} rounded-full border-2 ${btn.color} flex items-center justify-center text-[9px] font-mono-tech font-bold text-white text-center leading-tight px-1`}
          >
            {btn.label}
          </div>
        ))}
      </div>

      <div className="mt-2.5">
        <div className="text-xs font-display font-bold text-white">{active.title}</div>
        <p className="text-[11px] text-[#9AA3B2] mt-0.5 leading-relaxed">{active.desc}</p>
      </div>
    </div>
  );
};

// #17 Safe Android DPI Calculator
export const DpiSafeCalculator: React.FC<{ screenWidth: number; dpr: number }> = ({
  screenWidth,
  dpr,
}) => {
  const stockDp = Math.round(screenWidth);
  const [targetDp, setTargetDp] = useState<number>(Math.min(440, stockDp + 40));

  const diff = targetDp - stockDp;
  const isDanger = targetDp > 540 || diff > 120;

  return (
    <div className="bg-[#0A0C12] rounded-xl p-3.5 border border-white/10">
      <div className="flex items-center justify-between text-xs mb-2">
        <span className="text-[#9AA3B2] flex items-center gap-1.5">
          <Sliders className="w-3.5 h-3.5 text-[#FF1E2D]" />
          <span>Detected Logical Width:</span>
        </span>
        <span className="font-mono-tech font-bold text-white">
          {stockDp}dp (DPR {dpr}x)
        </span>
      </div>

      <div className="mb-2">
        <div className="flex justify-between text-xs mb-1">
          <span className="text-[#9AA3B2]">Simulated Smallest Width (dp)</span>
          <span className="font-mono-tech font-bold text-[#FF1E2D]">{targetDp} dp</span>
        </div>
        <input
          type="range"
          min={320}
          max={600}
          value={targetDp}
          onChange={(e) => setTargetDp(Number(e.target.value))}
          className="w-full alpha-slider"
        />
      </div>

      <div
        className={`p-2.5 rounded-lg border text-xs flex items-start gap-2 ${
          isDanger
            ? 'bg-[#FF1E2D]/15 border-[#FF1E2D]/50 text-[#FF8A93]'
            : 'bg-[#00E676]/10 border-[#00E676]/35 text-[#00E676]'
        }`}
      >
        {isDanger ? (
          <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-[#FF1E2D]" />
        ) : (
          <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-[#00E676]" />
        )}
        <div>
          <div className="font-bold">
            {isDanger ? 'HIGH RISK — Do Not Exceed 540dp!' : 'SAFE RANGE FOR 2GB–8GB ANDROID'}
          </div>
          <div className="text-[11px] opacity-90 mt-0.5">
            {isDanger
              ? 'Values above 540dp can cause SystemUI black screen on budget Android phones.'
              : `Recommended safe adjustment: ${stockDp}dp to ${Math.min(460, stockDp + 50)}dp.`}
          </div>
        </div>
      </div>
    </div>
  );
};

// #38 Web Audio Stereo Footstep Tester
export const AudioPanTester: React.FC = () => {
  const [activeSide, setActiveSide] = useState<'left' | 'center' | 'right' | null>(null);

  const playFootstepTone = (pan: -1 | 0 | 1, label: 'left' | 'center' | 'right') => {
    setActiveSide(label);
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const panner = ctx.createStereoPanner();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(220, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(110, ctx.currentTime + 0.18);

      panner.pan.setValueAtTime(pan, ctx.currentTime);
      gain.gain.setValueAtTime(0.28, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.22);

      osc.connect(panner);
      panner.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.23);
    } catch {
      // Ignore if audio context blocked
    }
    setTimeout(() => setActiveSide(null), 400);
  };

  return (
    <div className="bg-[#0A0C12] rounded-xl p-3.5 border border-white/10">
      <div className="text-xs font-display font-bold uppercase text-white mb-2 flex items-center gap-1.5">
        <Volume2 className="w-4 h-4 text-[#FF1E2D]" />
        <span>Stereo Earphone Direction Check</span>
      </div>
      <div className="grid grid-cols-3 gap-2">
        {[
          { id: 'left' as const, label: 'LEFT EAR', pan: -1 as const },
          { id: 'center' as const, label: 'CENTER', pan: 0 as const },
          { id: 'right' as const, label: 'RIGHT EAR', pan: 1 as const },
        ].map((btn) => (
          <button
            key={btn.id}
            type="button"
            onClick={() => playFootstepTone(btn.pan, btn.id)}
            className={`py-2.5 px-2 rounded-lg border font-display text-xs font-bold uppercase cursor-pointer transition-all ${
              activeSide === btn.id
                ? 'bg-[#FF1E2D] border-[#FF1E2D] text-white'
                : 'bg-[#12151E] border-white/10 text-[#F4F6FA] hover:border-[#FF1E2D]/50'
            }`}
          >
            {btn.label}
          </button>
        ))}
      </div>
    </div>
  );
};

// #35 Live Gaming Session Stopwatch
export const GamingSessionTimer: React.FC = () => {
  const [seconds, setSeconds] = useState(0);
  const [running, setRunning] = useState(false);

  useEffect(() => {
    if (!running) return;
    const id = setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => clearInterval(id);
  }, [running]);

  const hrs = String(Math.floor(seconds / 3600)).padStart(2, '0');
  const mins = String(Math.floor((seconds % 3600) / 60)).padStart(2, '0');
  const secs = String(seconds % 60).padStart(2, '0');
  const thermalWarning = seconds >= 2700; // 45 minutes

  return (
    <div className="bg-[#0A0C12] rounded-xl p-3.5 border border-white/10 text-center">
      <div className="font-mono-tech text-3xl font-bold tracking-widest text-white py-2">
        {hrs}:{mins}:{secs}
      </div>
      {thermalWarning && (
        <div className="text-[11px] text-[#FF9F1C] mb-2">
          45+ min elapsed — take a 5-min cooldown break to prevent thermal throttling.
        </div>
      )}
      <div className="flex justify-center gap-2 mt-1">
        <button
          type="button"
          onClick={() => setRunning((r) => !r)}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#FF1E2D] text-white font-display text-xs font-bold uppercase cursor-pointer"
        >
          {running ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
          <span>{running ? 'Pause' : 'Start Session'}</span>
        </button>
        <button
          type="button"
          onClick={() => {
            setRunning(false);
            setSeconds(0);
          }}
          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#151822] text-[#9AA3B2] hover:text-white font-display text-xs font-bold uppercase cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset</span>
        </button>
      </div>
    </div>
  );
};

// #33 Free Fire Data Usage Estimator
export const DataUsageCalculator: React.FC = () => {
  const [minutes, setMinutes] = useState(60);
  const [voiceChat, setVoiceChat] = useState(true);

  // Realistic FF telemetry: ~0.9 MB/min without mic, ~1.5 MB/min with squad voice chat
  const estimatedMb = Math.round(minutes * (voiceChat ? 1.5 : 0.9));

  return (
    <div className="bg-[#0A0C12] rounded-xl p-3.5 border border-white/10">
      <div className="flex justify-between text-xs mb-1">
        <span className="text-[#9AA3B2]">Planned Play Duration</span>
        <span className="font-mono-tech font-bold text-white">{minutes} mins</span>
      </div>
      <input
        type="range"
        min={15}
        max={240}
        step={15}
        value={minutes}
        onChange={(e) => setMinutes(Number(e.target.value))}
        className="w-full alpha-slider mb-3"
      />
      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={() => setVoiceChat((v) => !v)}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium border cursor-pointer ${
            voiceChat
              ? 'bg-[#FF1E2D]/15 border-[#FF1E2D] text-white'
              : 'bg-[#12151E] border-white/10 text-[#9AA3B2]'
          }`}
        >
          Squad Mic: {voiceChat ? 'ON' : 'OFF'}
        </button>
        <div className="text-right">
          <div className="text-[10px] text-[#9AA3B2]">ESTIMATED DATA</div>
          <div className="font-mono-tech text-base font-bold text-[#00D4FF]">~{estimatedMb} MB</div>
        </div>
      </div>
    </div>
  );
};

// #41 Interactive Symptom Troubleshooter
export const TroubleshootingMatrix: React.FC = () => {
  const [issue, setIssue] = useState<'crash' | 'ping' | 'black' | 'touch'>('crash');

  const solutions = {
    crash: {
      title: 'Auto-Back / Game Closing on 2GB RAM',
      fixes: [
        'Force Stop Chrome, TikTok, Instagram, and Facebook in Android Settings > Apps before launching.',
        'Switch to standard Free Fire (com.dts.freefireth) instead of Free Fire MAX.',
        'Delete unused costume/map packs inside Free Fire Download Center.',
      ],
    },
    ping: {
      title: 'Sudden 999+ Ping Spikes',
      fixes: [
        'Enable VoLTE so incoming calls do not drop 4G down to 3G.',
        'Set Private DNS to 1dot1dot1dot1.cloudflare-dns.com in Android Network Settings.',
        'Toggle Airplane Mode for 5 seconds before ranked matches to lock onto the strongest cell tower.',
      ],
    },
    black: {
      title: 'Black Screen or Stuck on Garena Logo',
      fixes: [
        'Check free internal storage (#21)—ensure at least 2.5GB is free.',
        'Clear ONLY Cache (not Data) on Google Play Services & Free Fire.',
        'If you modified Android DPI (#17), reset Smallest Width back to stock default.',
      ],
    },
    touch: {
      title: 'Delayed Drag / Unresponsive Fire Button',
      fixes: [
        'Test multi-touch in Touch Screen Test (#23) to check for screen protector interference.',
        'Disable 3-finger screenshot gestures if they conflict with your Claw HUD.',
        'Wipe screen moisture and lower brightness to 60% to reduce glass heat.',
      ],
    },
  };

  return (
    <div className="bg-[#0A0C12] rounded-xl p-3.5 border border-white/10">
      <div className="grid grid-cols-2 gap-1.5 mb-3">
        {[
          { id: 'crash' as const, label: 'Auto-Back Crash' },
          { id: 'ping' as const, label: '999+ Ping Spike' },
          { id: 'black' as const, label: 'Black Screen' },
          { id: 'touch' as const, label: 'Touch / Drag Lag' },
        ].map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setIssue(item.id)}
            className={`py-2 px-2.5 rounded-lg text-xs font-display font-bold uppercase text-left cursor-pointer border ${
              issue === item.id
                ? 'bg-[#FF1E2D]/20 border-[#FF1E2D] text-white'
                : 'bg-[#12151E] border-white/10 text-[#9AA3B2]'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>

      <div className="bg-[#11141E] rounded-lg p-3 border border-white/5">
        <div className="text-xs font-display font-bold text-[#FF1E2D] mb-2">
          {solutions[issue].title}
        </div>
        <ul className="space-y-1.5">
          {solutions[issue].fixes.map((fix, i) => (
            <li key={i} className="text-xs text-[#F4F6FA] flex items-start gap-2">
              <span className="font-mono-tech text-[#00E676] font-bold">{i + 1}.</span>
              <span>{fix}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

// #10 Background App Pre-Game Checklist
export const BackgroundAppsChecklist: React.FC = () => {
  const [apps, setApps] = useState([
    { name: 'TikTok / Reels Video Cache', ramNote: '~320 MB', closed: false },
    { name: 'Google Chrome Background Tabs', ramNote: '~280 MB', closed: false },
    { name: 'Instagram / Facebook Feed', ramNote: '~260 MB', closed: false },
    { name: 'YouTube Player Service', ramNote: '~210 MB', closed: false },
    { name: 'Play Store Auto-Update Sync', ramNote: 'Network + CPU', closed: false },
  ]);

  const toggleApp = (idx: number) => {
    setApps((prev) =>
      prev.map((item, i) => (i === idx ? { ...item, closed: !item.closed } : item))
    );
  };

  return (
    <div className="bg-[#0A0C12] rounded-xl p-3.5 border border-white/10">
      <div className="flex items-center justify-between text-xs mb-2">
        <span className="text-[#9AA3B2] flex items-center gap-1.5">
          <Smartphone className="w-3.5 h-3.5 text-[#FF1E2D]" />
          <span>Mark Heavy Apps Force-Stopped:</span>
        </span>
        <span className="font-mono-tech font-bold text-[#00E676]">
          {apps.filter((a) => a.closed).length}/{apps.length}
        </span>
      </div>
      <div className="space-y-1.5">
        {apps.map((app, idx) => (
          <button
            key={app.name}
            type="button"
            onClick={() => toggleApp(idx)}
            className="w-full flex items-center justify-between px-3 py-2 rounded-lg bg-[#11141E] hover:bg-[#161A26] border border-white/5 text-left cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <CheckCircle2
                className={`w-4 h-4 ${app.closed ? 'text-[#00E676]' : 'text-[#5C6475]'}`}
              />
              <span
                className={`text-xs ${
                  app.closed ? 'line-through text-[#5C6475]' : 'text-[#F4F6FA]'
                }`}
              >
                {app.name}
              </span>
            </div>
            <span className="font-mono-tech text-[10px] text-[#9AA3B2]">{app.ramNote}</span>
          </button>
        ))}
      </div>
    </div>
  );
};
