import React, { useState } from 'react';
import { Crosshair, Copy, Check, Save, Sparkles } from 'lucide-react';
import { PRESET_SENSITIVITIES } from '../data/featuresData';
import { SensitivitySet } from '../types/optimizer';
import { DpiSafeCalculator, HudLayoutVisualizer } from './InteractiveTools';

interface SensitivityStudioProps {
  screenWidth: number;
  dpr: number;
  onLogHistory: (action: string, detail: string, category: 'profile') => void;
}

export const SensitivityStudio: React.FC<SensitivityStudioProps> = ({
  screenWidth,
  dpr,
  onLogHistory,
}) => {
  const [selectedPresetId, setSelectedPresetId] = useState<string>(PRESET_SENSITIVITIES[0].id);
  const [values, setValues] = useState<SensitivitySet>(PRESET_SENSITIVITIES[0]);
  const [savedProfiles, setSavedProfiles] = useState<SensitivitySet[]>(() => {
    try {
      const raw = localStorage.getItem('dark_alpha_sens_profiles');
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });
  const [customName, setCustomName] = useState('');
  const [copied, setCopied] = useState(false);

  const allProfiles = [...PRESET_SENSITIVITIES, ...savedProfiles];

  const handleSelectPreset = (preset: SensitivitySet) => {
    setSelectedPresetId(preset.id);
    setValues({ ...preset });
    onLogHistory('Applied Sensitivity Profile', preset.name, 'profile');
  };

  const handleSliderChange = (key: keyof SensitivitySet, num: number) => {
    setValues((prev) => ({
      ...prev,
      [key]: num,
    }));
  };

  const handleSaveCustom = () => {
    const label = customName.trim() || `Custom Alpha #${savedProfiles.length + 1}`;
    const newSet: SensitivitySet = {
      ...values,
      id: `custom_${Date.now()}`,
      name: label,
      deviceTier: 'User Custom Profile',
    };
    const next = [newSet, ...savedProfiles].slice(0, 8);
    setSavedProfiles(next);
    setSelectedPresetId(newSet.id);
    setCustomName('');
    try {
      localStorage.setItem('dark_alpha_sens_profiles', JSON.stringify(next));
    } catch {}
    onLogHistory('Saved Sensitivity Profile', label, 'profile');
  };

  const handleCopyValues = () => {
    const formatted = [
      `DARK ALPHA FF SENSITIVITY (${values.name})`,
      `General: ${values.general}`,
      `Red Dot: ${values.redDot}`,
      `2X Scope: ${values.scope2x}`,
      `4X Scope: ${values.scope4x}`,
      `Sniper Scope: ${values.sniperScope}`,
      `Free Look: ${values.freeLook}`,
      `Fire Button Size: ${values.fireButtonSize}%`,
    ].join('\n');

    navigator.clipboard?.writeText(formatted).catch(() => {});
    setCopied(true);
    onLogHistory('Copied Sensitivity Values', values.name, 'profile');
    setTimeout(() => setCopied(false), 2500);
  };

  const sliders: { code: string; key: keyof SensitivitySet; label: string; hint: string }[] = [
    { code: '#11', key: 'general', label: 'General Sensitivity', hint: '360° camera rotation & movement' },
    { code: '#12', key: 'redDot', label: 'Red Dot Sensitivity', hint: 'Close-range drag headshot speed' },
    { code: '#13', key: 'scope2x', label: '2X Scope Sensitivity', hint: 'Mid-range SMG / AR tracking' },
    { code: '#14', key: 'scope4x', label: '4X Scope Sensitivity', hint: 'Long-range marksman stability' },
    { code: '#15', key: 'sniperScope', label: 'Sniper Scope Sensitivity', hint: 'AWM / M82B quick-scope flick' },
    { code: '#16', key: 'freeLook', label: 'Free Look Sensitivity', hint: 'Parachute & sprint awareness' },
  ];

  return (
    <div className="space-y-4">
      {/* #20 Sensitivity Profiles Selector */}
      <div className="card-surface rounded-2xl p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Crosshair className="w-4 h-4 text-[#FF1E2D]" />
            <h2 className="font-display font-bold text-sm uppercase tracking-wider text-white">
              Sensitivity Profiles (#20)
            </h2>
          </div>
          <span className="font-mono-tech text-[11px] text-[#00E676]">0–200 SCALE</span>
        </div>

        <div className="grid grid-cols-2 gap-2">
          {allProfiles.map((preset) => (
            <button
              key={preset.id}
              type="button"
              onClick={() => handleSelectPreset(preset)}
              className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                selectedPresetId === preset.id
                  ? 'bg-[#FF1E2D]/15 border-[#FF1E2D] text-white'
                  : 'bg-[#0A0C12] border-white/10 text-[#9AA3B2] hover:border-white/25'
              }`}
            >
              <div className="font-display font-bold text-xs text-white truncate">
                {preset.name}
              </div>
              <div className="text-[10px] text-[#9AA3B2] truncate mt-0.5">{preset.deviceTier}</div>
            </button>
          ))}
        </div>
      </div>

      {/* #11 - #16 Interactive Sensitivity Sliders */}
      <div className="card-surface rounded-2xl p-4">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="font-display font-bold text-sm uppercase tracking-wider text-white">
              Aim Calibration (#11–#16)
            </h3>
            <p className="text-[11px] text-[#9AA3B2]">
              Recommended Fire Button: <strong className="text-white">{values.fireButtonSize}%</strong> •{' '}
              {values.recommendedDpi}
            </p>
          </div>
          <button
            type="button"
            onClick={handleCopyValues}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#FF1E2D] hover:brightness-110 text-white font-display text-xs font-bold uppercase cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>
        </div>

        <div className="space-y-3.5">
          {sliders.map((item) => {
            const val = Number(values[item.key]);
            return (
              <div key={item.key} className="bg-[#0A0C12] rounded-xl p-3 border border-white/5">
                <div className="flex items-center justify-between mb-1">
                  <div>
                    <span className="font-mono-tech text-[10px] text-[#FF1E2D] mr-1.5">
                      {item.code}
                    </span>
                    <span className="text-xs font-semibold text-white">{item.label}</span>
                  </div>
                  <span className="font-mono-tech text-sm font-bold text-[#FF1E2D]">{val}</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={200}
                  value={val}
                  onChange={(e) => handleSliderChange(item.key, Number(e.target.value))}
                  className="w-full alpha-slider"
                />
                <div className="text-[10px] text-[#5C6475] mt-1">{item.hint}</div>
              </div>
            );
          })}
        </div>

        {/* Save Custom Sensitivity Preset */}
        <div className="mt-4 pt-3 border-t border-white/10 flex gap-2">
          <input
            type="text"
            value={customName}
            onChange={(e) => setCustomName(e.target.value)}
            placeholder="Name your custom sensitivity..."
            className="flex-1 bg-[#090B10] border border-white/10 rounded-lg px-3 py-2 text-xs text-white placeholder-[#5C6475] focus:outline-none focus:border-[#FF1E2D]"
          />
          <button
            type="button"
            onClick={handleSaveCustom}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#151822] hover:bg-[#1E2230] border border-white/15 text-xs font-display font-bold uppercase text-white cursor-pointer"
          >
            <Save className="w-3.5 h-3.5 text-[#00E676]" />
            <span>Save</span>
          </button>
        </div>
      </div>

      {/* #18 HUD Layout Guide */}
      <div className="card-surface rounded-2xl p-4">
        <div className="flex items-center gap-2 mb-3">
          <Sparkles className="w-4 h-4 text-[#FF1E2D]" />
          <h3 className="font-display font-bold text-sm uppercase tracking-wider text-white">
            HUD Layout Blueprint (#18)
          </h3>
        </div>
        <HudLayoutVisualizer />
      </div>

      {/* #17 DPI Safe Calculator */}
      <div className="card-surface rounded-2xl p-4">
        <h3 className="font-display font-bold text-sm uppercase tracking-wider text-white mb-3">
          DPI Information & Safe Limit (#17)
        </h3>
        <DpiSafeCalculator screenWidth={screenWidth} dpr={dpr} />
      </div>
    </div>
  );
};
