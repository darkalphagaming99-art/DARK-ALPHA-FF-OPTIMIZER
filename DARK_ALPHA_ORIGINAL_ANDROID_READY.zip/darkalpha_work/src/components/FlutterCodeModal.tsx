import React, { useState } from 'react';
import { X, Copy, Check, Download, Code2, ShieldCheck } from 'lucide-react';
import { FLUTTER_PROJECT_FILES } from '../data/flutterSource';

interface FlutterCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const FlutterCodeModal: React.FC<FlutterCodeModalProps> = ({ isOpen, onClose }) => {
  const [activeIndex, setActiveIndex] = useState(3); // Default to lib/main.dart
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const activeFile = FLUTTER_PROJECT_FILES[activeIndex];

  const handleCopy = () => {
    navigator.clipboard?.writeText(activeFile.code).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2200);
  };

  const handleDownloadFile = () => {
    const blob = new Blob([activeFile.code], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = activeFile.filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-3 sm:p-5">
      <div className="w-full max-w-3xl max-h-[92vh] flex flex-col rounded-2xl bg-[#0E1016] border border-[#FF1E2D]/50 overflow-hidden shadow-2xl">
        {/* Top Bar */}
        <div className="flex items-center justify-between px-4 py-3.5 bg-[#090B10] border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#FF1E2D]/20 border border-[#FF1E2D]/50 flex items-center justify-center">
              <Code2 className="w-4 h-4 text-[#FF1E2D]" />
            </div>
            <div>
              <h2 className="font-display font-bold text-sm sm:text-base text-white tracking-wide">
                DARK ALPHA — REAL FLUTTER ANDROID SOURCE
              </h2>
              <p className="text-[11px] text-[#9AA3B2]">
                Production Dart + Kotlin Native Channel • Compile with{' '}
                <code className="text-[#00E676]">flutter build apk --release</code>
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-lg bg-[#151822] text-[#9AA3B2] hover:text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* File Tabs */}
        <div className="flex overflow-x-auto gap-1.5 px-4 py-2.5 bg-[#0B0D13] border-b border-white/10">
          {FLUTTER_PROJECT_FILES.map((file, idx) => (
            <button
              key={file.path}
              type="button"
              onClick={() => setActiveIndex(idx)}
              className={`px-3 py-1.5 rounded-lg font-mono-tech text-xs whitespace-nowrap transition-colors cursor-pointer ${
                activeIndex === idx
                  ? 'bg-[#FF1E2D] text-white font-bold'
                  : 'bg-[#141722] text-[#9AA3B2] hover:text-white'
              }`}
            >
              {file.filename}
            </button>
          ))}
        </div>

        {/* File Path & Action Buttons */}
        <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 bg-[#10131C] border-b border-white/5">
          <div>
            <div className="font-mono-tech text-xs text-[#00D4FF]">{activeFile.path}</div>
            <div className="text-[11px] text-[#9AA3B2]">{activeFile.description}</div>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleCopy}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#181C2A] hover:bg-[#22273A] border border-white/10 text-xs font-display font-bold uppercase text-white cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-[#00E676]" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy Code'}</span>
            </button>
            <button
              type="button"
              onClick={handleDownloadFile}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#FF1E2D] hover:brightness-110 text-xs font-display font-bold uppercase text-white cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download</span>
            </button>
          </div>
        </div>

        {/* Code Viewer */}
        <div className="flex-1 overflow-auto p-4 bg-[#060609]">
          <pre className="font-mono-tech text-[11px] sm:text-xs text-[#E2E8F0] leading-relaxed whitespace-pre overflow-x-auto">
            <code>{activeFile.code}</code>
          </pre>
        </div>

        {/* Footer Compliance Note */}
        <div className="px-4 py-2.5 bg-[#090B10] border-t border-white/10 flex flex-wrap items-center justify-between gap-2 text-[11px] text-[#9AA3B2]">
          <span className="inline-flex items-center gap-1.5 text-[#00E676]">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Uses real PackageManager launch intents, ActivityManager RAM & SchedulerBinding FPS</span>
          </span>
          <span className="font-mono-tech text-[#5C6475]">Target SDK 34 • Min SDK 21 (2GB RAM Safe)</span>
        </div>
      </div>
    </div>
  );
};
