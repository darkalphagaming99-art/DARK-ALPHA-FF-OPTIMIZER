import { useState, useMemo, useCallback } from 'react';
import {
  Flame,
  Crosshair,
  Cpu,
  LayoutGrid,
  Activity,
  BatteryCharging,
  Wifi,
  MemoryStick,
  Search,
  ChevronRight,
  Code2,
  ShieldCheck,
  Zap,
  Fingerprint,
  Gauge,
  History,
  Sliders,
  ExternalLink,
  Languages,
} from 'lucide-react';
import {
  CustomGamingProfile,
  FeatureCategory,
  FFPackageType,
  HistoryLogEntry,
  OptimizerFeature,
  PerformancePreset,
} from './types/optimizer';
import { ALL_OPTIMIZER_FEATURES } from './data/featuresData';
import { useRealTelemetry } from './hooks/useRealTelemetry';
import { GameLauncherHero } from './components/GameLauncherHero';
import { SensitivityStudio } from './components/SensitivityStudio';
import { FeatureDetailModal } from './components/FeatureDetailModal';
import { FlutterCodeModal } from './components/FlutterCodeModal';
import {
  AudioPanTester,
  DataUsageCalculator,
  GamingSessionTimer,
  TouchScreenTester,
  TroubleshootingMatrix,
} from './components/InteractiveTools';

type NavTab = 'command' | 'sensitivity' | 'hardware' | 'arsenal';

export function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('command');
  const [lang, setLang] = useState<'en' | 'si'>('en');

  // Auto-enable Low RAM Mode if browser reports <= 2GB RAM
  const [lowRamMode, setLowRamMode] = useState<boolean>(() => {
    const mem = (navigator as any).deviceMemory;
    return typeof mem === 'number' && mem <= 2;
  });

  const [perfPreset, setPerfPreset] = useState<PerformancePreset>(() =>
    lowRamMode ? 'ultra_2gb' : 'balanced'
  );
  const [gamingMode, setGamingMode] = useState<boolean>(true);
  const [selectedPackage, setSelectedPackage] = useState<FFPackageType>('com.dts.freefireth');

  // Search & Category filter for 50+ Arsenal
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<'all' | FeatureCategory>('all');

  // Active modals
  const [activeFeature, setActiveFeature] = useState<OptimizerFeature | null>(null);
  const [flutterModalOpen, setFlutterModalOpen] = useState(false);

  // Persisted Custom Gaming Profiles (#48)
  const [customProfiles, setCustomProfiles] = useState<CustomGamingProfile[]>(() => {
    try {
      const raw = localStorage.getItem('dark_alpha_custom_profiles');
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });

  // Persisted Optimization History (#49)
  const [historyLog, setHistoryLog] = useState<HistoryLogEntry[]>(() => {
    try {
      const raw = localStorage.getItem('dark_alpha_history_log');
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });

  const { telemetry, fpsHistory, speedTest, isTestingSpeed, runSpeedTest } =
    useRealTelemetry(lowRamMode);

  const logHistory = useCallback(
    (action: string, detail: string, category: HistoryLogEntry['category']) => {
      const entry: HistoryLogEntry = {
        id: `log_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        timestamp: new Date().toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        }),
        action,
        detail,
        category,
      };
      setHistoryLog((prev) => {
        const updated = [entry, ...prev].slice(0, 40);
        try {
          localStorage.setItem('dark_alpha_history_log', JSON.stringify(updated));
        } catch {}
        return updated;
      });
    },
    []
  );

  const handleToggleLowRam = () => {
    setLowRamMode((prev) => {
      const next = !prev;
      if (next) setPerfPreset('ultra_2gb');
      logHistory(
        next ? 'Enabled 2GB Low RAM Mode' : 'Disabled 2GB Low RAM Mode',
        next ? 'Stripped GPU blur & heavy animations' : 'Standard UI effects restored',
        'system'
      );
      return next;
    });
  };

  const handleSelectPerfPreset = (preset: PerformancePreset) => {
    setPerfPreset(preset);
    if (preset === 'ultra_2gb') {
      setLowRamMode(true);
    }
    logHistory('Switched Performance Preset', preset.toUpperCase(), 'profile');
  };

  const handleLaunchGame = (pkg: FFPackageType) => {
    logHistory(
      'Launched Game Client',
      `${pkg} (${perfPreset.toUpperCase()})`,
      'launch'
    );
  };

  const handleAddCustomProfile = (profile: CustomGamingProfile) => {
    setCustomProfiles((prev) => {
      const updated = [profile, ...prev].slice(0, 10);
      try {
        localStorage.setItem('dark_alpha_custom_profiles', JSON.stringify(updated));
      } catch {}
      return updated;
    });
    logHistory('Created Custom Profile', profile.name, 'profile');
  };

  const handleApplyCustomProfile = (profile: CustomGamingProfile) => {
    setSelectedPackage(profile.ffPackage);
    setPerfPreset(profile.perfMode);
    setLowRamMode(profile.lowRamMode);
    logHistory(
      'Activated Custom Profile',
      `${profile.name} (${profile.graphicsPreset} / ${profile.fpsTarget})`,
      'profile'
    );
  };

  const handleSpeedTestWithLog = async () => {
    const res = await runSpeedTest();
    logHistory(
      'Network Speed & Ping Test',
      `Ping: ${res.pingMs}ms | Jitter: ${res.jitterMs}ms | ${res.downloadMbps} Mbps`,
      'network'
    );
    return res;
  };

  const openFeatureById = (id: number) => {
    const found = ALL_OPTIMIZER_FEATURES.find((f) => f.id === id);
    if (found) setActiveFeature(found);
  };

  const filteredFeatures = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return ALL_OPTIMIZER_FEATURES.filter((f) => {
      const matchesCat = categoryFilter === 'all' || f.category === categoryFilter;
      if (!matchesCat) return false;
      if (!q) return true;
      return (
        f.code.includes(q) ||
        String(f.id) === q ||
        f.title.toLowerCase().includes(q) ||
        f.titleSi.toLowerCase().includes(q) ||
        f.shortDesc.toLowerCase().includes(q) ||
        f.tag.toLowerCase().includes(q)
      );
    });
  }, [searchQuery, categoryFilter]);

  return (
    <div
      className={`min-h-screen bg-cyber-grid text-[#F4F6FA] pb-24 ${
        lowRamMode ? 'low-ram-mode' : ''
      }`}
    >
      {/* Centered Flagship Android Gaming Viewport Shell */}
      <div className="max-w-[540px] mx-auto min-h-screen flex flex-col">
        {/* TOP COMMAND HEADER */}
        <header className="sticky top-0 z-30 bg-[#060609]/95 border-b border-white/10 px-4 py-3">
          <div className="flex items-center justify-between gap-2">
            {/* Brand Emblem */}
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#FF1E2D] to-[#8F0010] flex items-center justify-center border border-white/15 shrink-0">
                <Flame className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-display font-bold text-base tracking-wider text-white">
                    DARK ALPHA
                  </span>
                  <span className="text-[10px] font-mono-tech font-bold px-1.5 py-0.5 rounded bg-[#FF1E2D]/20 text-[#FF1E2D]">
                    FF
                  </span>
                </div>
                <p className="text-[10px] text-[#9AA3B2] tracking-wider uppercase">
                  {lang === 'si' ? 'Android Lag Fix සහ Launcher' : 'Android Gaming Optimizer'}
                </p>
              </div>
            </div>

            {/* Header Utility Controls */}
            <div className="flex items-center gap-1.5">
              {/* Language Switcher EN / සිං */}
              <button
                type="button"
                onClick={() => setLang((l) => (l === 'en' ? 'si' : 'en'))}
                title="Switch English / Sinhala"
                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#12151E] hover:bg-[#191D2A] border border-white/10 text-[11px] font-mono-tech font-bold text-[#F4F6FA] cursor-pointer"
              >
                <Languages className="w-3.5 h-3.5 text-[#00D4FF]" />
                <span>{lang === 'en' ? 'සිංහල' : 'EN'}</span>
              </button>

              {/* 2GB RAM Low-Overhead Toggle (#04) */}
              <button
                type="button"
                onClick={handleToggleLowRam}
                className={`px-2.5 py-1.5 rounded-lg text-[11px] font-display font-bold uppercase tracking-wider border transition-all cursor-pointer ${
                  lowRamMode
                    ? 'bg-[#00E676]/15 border-[#00E676]/50 text-[#00E676]'
                    : 'bg-[#12151E] border-white/10 text-[#9AA3B2] hover:text-white'
                }`}
              >
                2GB RAM: {lowRamMode ? 'ON' : 'OFF'}
              </button>

              {/* Flutter Source Code Drawer Button */}
              <button
                type="button"
                onClick={() => setFlutterModalOpen(true)}
                title="View Real Flutter Android Source Code"
                className="p-2 rounded-lg bg-[#FF1E2D]/15 hover:bg-[#FF1E2D]/25 border border-[#FF1E2D]/40 text-[#FF1E2D] cursor-pointer"
              >
                <Code2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        </header>

        {/* MAIN VIEWPORT CONTENT */}
        <main className="flex-1 px-4 pt-4 space-y-4">
          {/* TAB 1: COMMAND CENTER */}
          {activeTab === 'command' && (
            <>
              {/* Hero Game Launcher (#09) & Gaming Mode (#36) */}
              <GameLauncherHero
                selectedPackage={selectedPackage}
                onSelectPackage={setSelectedPackage}
                gamingMode={gamingMode}
                onToggleGamingMode={() => setGamingMode((g) => !g)}
                lowRamMode={lowRamMode}
                onToggleLowRamMode={handleToggleLowRam}
                perfPreset={perfPreset}
                onSelectPerfPreset={handleSelectPerfPreset}
                isAndroid={telemetry.isAndroid}
                lang={lang}
                onLaunchGame={handleLaunchGame}
                onOpenFlutterModal={() => setFlutterModalOpen(true)}
                pingMs={speedTest?.pingMs ?? telemetry.rttMs}
              />

              {/* Real Hardware Telemetry Bento Grid (Zero Fake Values) */}
              <section>
                <div className="flex items-center justify-between mb-2">
                  <h2 className="font-display font-bold text-xs uppercase tracking-widest text-[#9AA3B2]">
                    {lang === 'si'
                      ? 'සජීවී උපාංග තත්ත්වය (Real Telemetry)'
                      : 'LIVE HARDWARE TELEMETRY'}
                  </h2>
                  <span className="text-[10px] font-mono-tech text-[#00E676]">
                    ● HARDWARE VERIFIED
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2.5">
                  {/* Card 1: FPS & Refresh Rate (#01 & #45) */}
                  <button
                    type="button"
                    onClick={() => openFeatureById(1)}
                    className="card-surface rounded-xl p-3.5 text-left transition-all cursor-pointer"
                  >
                    <div className="flex items-center justify-between text-[#9AA3B2] mb-1.5">
                      <span className="text-[11px] font-display uppercase tracking-wider">
                        FPS / REFRESH
                      </span>
                      <Activity className="w-4 h-4 text-[#00E676]" />
                    </div>
                    <div className="font-mono-tech text-2xl font-bold text-white">
                      {telemetry.fps}{' '}
                      <span className="text-xs font-normal text-[#00E676]">FPS</span>
                    </div>
                    <div className="text-[11px] text-[#9AA3B2] mt-1 font-mono-tech">
                      {telemetry.frameTimeMs}ms • {telemetry.estimatedRefreshHz}Hz Panel
                    </div>
                  </button>

                  {/* Card 2: RAM & CPU Cores (#05 & #06) */}
                  <button
                    type="button"
                    onClick={() => openFeatureById(5)}
                    className="card-surface rounded-xl p-3.5 text-left transition-all cursor-pointer"
                  >
                    <div className="flex items-center justify-between text-[#9AA3B2] mb-1.5">
                      <span className="text-[11px] font-display uppercase tracking-wider">
                        RAM & SILICON
                      </span>
                      <MemoryStick className="w-4 h-4 text-[#FF1E2D]" />
                    </div>
                    <div className="font-mono-tech text-xl font-bold text-white">
                      {telemetry.deviceMemoryGb !== null
                        ? `${telemetry.deviceMemoryGb} GB`
                        : 'Android API'}
                    </div>
                    <div className="text-[11px] text-[#9AA3B2] mt-1 font-mono-tech">
                      {telemetry.cpuCores !== null
                        ? `${telemetry.cpuCores} CPU Cores`
                        : 'Multi-Core SoC'}
                    </div>
                  </button>

                  {/* Card 3: Battery & Thermal (#07 & #08) */}
                  <button
                    type="button"
                    onClick={() => openFeatureById(7)}
                    className="card-surface rounded-xl p-3.5 text-left transition-all cursor-pointer"
                  >
                    <div className="flex items-center justify-between text-[#9AA3B2] mb-1.5">
                      <span className="text-[11px] font-display uppercase tracking-wider">
                        POWER / THERMAL
                      </span>
                      <BatteryCharging className="w-4 h-4 text-[#FF9F1C]" />
                    </div>
                    <div className="font-mono-tech text-xl font-bold text-white">
                      {telemetry.batteryLevel !== null ? `${telemetry.batteryLevel}%` : 'Ready'}
                    </div>
                    <div className="text-[11px] text-[#9AA3B2] mt-1">
                      {telemetry.batteryCharging
                        ? 'Charging (Unplug to cool)'
                        : 'Optimal Voltage Zone'}
                    </div>
                  </button>

                  {/* Card 4: Network & Ping (#28, #29, #30) */}
                  <button
                    type="button"
                    onClick={() => openFeatureById(30)}
                    className="card-surface rounded-xl p-3.5 text-left transition-all cursor-pointer"
                  >
                    <div className="flex items-center justify-between text-[#9AA3B2] mb-1.5">
                      <span className="text-[11px] font-display uppercase tracking-wider">
                        NET / PING
                      </span>
                      <Wifi className="w-4 h-4 text-[#00D4FF]" />
                    </div>
                    <div className="font-mono-tech text-xl font-bold text-white">
                      {speedTest
                        ? `${speedTest.pingMs} ms`
                        : telemetry.rttMs
                        ? `${telemetry.rttMs} ms`
                        : telemetry.online
                        ? 'ONLINE'
                        : 'OFFLINE'}
                    </div>
                    <div className="text-[11px] text-[#00D4FF] mt-1 font-mono-tech uppercase">
                      {speedTest
                        ? `${speedTest.downloadMbps} Mbps • ${speedTest.quality}`
                        : `${telemetry.effectiveType} • Tap to Test`}
                    </div>
                  </button>
                </div>
              </section>

              {/* Quick Tactical Actions Strip */}
              <section className="card-surface rounded-2xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <h2 className="font-display font-bold text-xs uppercase tracking-widest text-white">
                    {lang === 'si' ? 'ක්ෂණික මෙවලම් (Quick Tools)' : 'QUICK TACTICAL TOOLS'}
                  </h2>
                  <button
                    type="button"
                    onClick={() => setActiveTab('arsenal')}
                    className="text-xs text-[#FF1E2D] font-semibold hover:underline cursor-pointer"
                  >
                    All 52 Features →
                  </button>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 43, label: 'Device Check', code: '#43', icon: ShieldCheck },
                    { id: 30, label: 'Speed Test', code: '#30', icon: Gauge },
                    { id: 23, label: 'Touch Test', code: '#23', icon: Fingerprint },
                    { id: 10, label: 'BG Apps', code: '#10', icon: Zap },
                    { id: 48, label: 'My Profiles', code: '#48', icon: Sliders },
                    { id: 49, label: 'History Log', code: '#49', icon: History },
                  ].map((item) => {
                    const IconComp = item.icon;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => openFeatureById(item.id)}
                        className="p-2.5 rounded-xl bg-[#0A0C12] hover:bg-[#141824] border border-white/10 hover:border-[#FF1E2D]/45 text-left transition-all cursor-pointer"
                      >
                        <div className="flex items-center justify-between mb-1.5">
                          <IconComp className="w-4 h-4 text-[#FF1E2D]" />
                          <span className="font-mono-tech text-[10px] text-[#5C6475]">
                            {item.code}
                          </span>
                        </div>
                        <div className="font-display font-bold text-xs text-white truncate">
                          {item.label}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </section>

              {/* Featured Lag-Fix & Flutter APK Card */}
              <section className="card-surface rounded-2xl p-4 border border-[#FF1E2D]/25">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="font-mono-tech text-[10px] uppercase px-2 py-0.5 rounded bg-[#FF1E2D]/20 text-[#FF1E2D]">
                      FLUTTER ANDROID EDITION
                    </span>
                    <h3 className="font-display font-bold text-sm text-white mt-1.5">
                      {lang === 'si'
                        ? 'සම්පූර්ණ Flutter Android APK Source Code ලබා ගන්න'
                        : 'Export Native Flutter Android Project'}
                    </h3>
                    <p className="text-xs text-[#9AA3B2] mt-1 leading-relaxed">
                      Includes real Kotlin <code className="text-white">PackageManager</code> Free
                      Fire launcher, <code className="text-white">ActivityManager</code> RAM readout,
                      and <code className="text-white">SchedulerBinding</code> FPS monitor.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setFlutterModalOpen(true)}
                    className="px-3 py-2 rounded-xl bg-[#FF1E2D] hover:brightness-110 text-white font-display text-xs font-bold uppercase shrink-0 cursor-pointer"
                  >
                    View Code
                  </button>
                </div>
              </section>
            </>
          )}

          {/* TAB 2: SENSITIVITY & AIM STUDIO (#11 - #20) */}
          {activeTab === 'sensitivity' && (
            <SensitivityStudio
              screenWidth={telemetry.screenWidth}
              dpr={telemetry.devicePixelRatio}
              onLogHistory={logHistory}
            />
          )}

          {/* TAB 3: HARDWARE, NETWORK & INTERACTIVE LAB (#21 - #47) */}
          {activeTab === 'hardware' && (
            <div className="space-y-4">
              {/* Live Internet Speed & Ping Test (#28, #29, #30) */}
              <div className="card-surface rounded-2xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Wifi className="w-4 h-4 text-[#00D4FF]" />
                    <h2 className="font-display font-bold text-sm uppercase tracking-wider text-white">
                      Network & Ping Benchmark (#28–#30)
                    </h2>
                  </div>
                  <span className="font-mono-tech text-xs text-[#00E676]">
                    {telemetry.online ? 'ONLINE' : 'OFFLINE'}
                  </span>
                </div>

                {speedTest && (
                  <div className="grid grid-cols-3 gap-2 mb-3 text-center">
                    <div className="bg-[#0A0C12] p-2.5 rounded-xl border border-white/10">
                      <div className="text-[10px] text-[#9AA3B2]">PING</div>
                      <div className="font-mono-tech text-lg font-bold text-[#00E676]">
                        {speedTest.pingMs}ms
                      </div>
                    </div>
                    <div className="bg-[#0A0C12] p-2.5 rounded-xl border border-white/10">
                      <div className="text-[10px] text-[#9AA3B2]">JITTER</div>
                      <div className="font-mono-tech text-lg font-bold text-white">
                        {speedTest.jitterMs}ms
                      </div>
                    </div>
                    <div className="bg-[#0A0C12] p-2.5 rounded-xl border border-white/10">
                      <div className="text-[10px] text-[#9AA3B2]">SPEED</div>
                      <div className="font-mono-tech text-lg font-bold text-[#00D4FF]">
                        {speedTest.downloadMbps} Mbps
                      </div>
                    </div>
                  </div>
                )}

                <button
                  type="button"
                  disabled={isTestingSpeed}
                  onClick={handleSpeedTestWithLog}
                  className="w-full py-2.5 rounded-xl bg-[#FF1E2D] hover:brightness-110 disabled:opacity-50 text-white font-display text-xs font-bold uppercase tracking-wider cursor-pointer"
                >
                  {isTestingSpeed ? 'Testing Real Round-Trip Latency...' : 'Run Ping & Speed Test'}
                </button>

                {/* Android System Settings Shortcuts (#31, #32, #37, #27) */}
                <div className="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-white/10">
                  {[
                    { id: 31, label: 'Wi-Fi Settings (#31)' },
                    { id: 32, label: 'Mobile Data (#32)' },
                    { id: 37, label: 'Do Not Disturb (#37)' },
                    { id: 27, label: 'App Manager (#27)' },
                  ].map((sc) => (
                    <button
                      key={sc.id}
                      type="button"
                      onClick={() => openFeatureById(sc.id)}
                      className="flex items-center justify-between px-3 py-2 rounded-lg bg-[#0A0C12] hover:bg-[#141824] border border-white/10 text-xs text-white cursor-pointer"
                    >
                      <span>{sc.label}</span>
                      <ExternalLink className="w-3.5 h-3.5 text-[#00D4FF]" />
                    </button>
                  ))}
                </div>
              </div>

              {/* #23 Multi-Touch Screen Tester */}
              <div className="card-surface rounded-2xl p-4">
                <h3 className="font-display font-bold text-sm uppercase tracking-wider text-white mb-3">
                  Touch Screen Multi-Touch Test (#23)
                </h3>
                <TouchScreenTester />
              </div>

              {/* #35 Gaming Timer & #38 Stereo Audio */}
              <div className="card-surface rounded-2xl p-4 space-y-4">
                <div>
                  <h3 className="font-display font-bold text-sm uppercase tracking-wider text-white mb-2">
                    Gaming Session Timer (#35)
                  </h3>
                  <GamingSessionTimer />
                </div>
                <div>
                  <h3 className="font-display font-bold text-sm uppercase tracking-wider text-white mb-2">
                    Earphone Footstep Pan Test (#38)
                  </h3>
                  <AudioPanTester />
                </div>
              </div>

              {/* #33 Data Calculator & #41 Troubleshooter */}
              <div className="card-surface rounded-2xl p-4 space-y-4">
                <div>
                  <h3 className="font-display font-bold text-sm uppercase tracking-wider text-white mb-2">
                    FF Data Usage Calculator (#33)
                  </h3>
                  <DataUsageCalculator />
                </div>
                <div>
                  <h3 className="font-display font-bold text-sm uppercase tracking-wider text-white mb-2">
                    Interactive Lag & Crash Solver (#41)
                  </h3>
                  <TroubleshootingMatrix />
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: ALL 50+ FEATURES ARSENAL (#01 - #52) */}
          {activeTab === 'arsenal' && (
            <div className="space-y-3.5">
              {/* Search & Category Filter Header */}
              <div className="card-surface rounded-2xl p-3.5 space-y-3">
                <div className="flex items-center justify-between">
                  <h2 className="font-display font-bold text-sm uppercase tracking-wider text-white">
                    {lang === 'si'
                      ? 'සියලුම විශේෂාංග 52 (50+ Arsenal)'
                      : 'COMPLETE 52-FEATURE ARSENAL'}
                  </h2>
                  <span className="font-mono-tech text-xs text-[#FF1E2D] font-bold">
                    {filteredFeatures.length} / {ALL_OPTIMIZER_FEATURES.length}
                  </span>
                </div>

                {/* Search Input */}
                <div className="relative">
                  <Search className="w-4 h-4 text-[#5C6475] absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={
                      lang === 'si'
                        ? 'Search කරන්න (උදා: FPS, Ping, Sensitivity, 09)...'
                        : 'Search #01–#52 (FPS, Ping, DPI, Launcher, Battery...)'
                    }
                    className="w-full bg-[#090B10] border border-white/10 focus:border-[#FF1E2D] rounded-xl pl-9 pr-3 py-2.5 text-xs text-white placeholder-[#5C6475] focus:outline-none"
                  />
                </div>

                {/* Category Filter Pills */}
                <div className="flex overflow-x-auto gap-1.5 pb-1">
                  {[
                    { id: 'all' as const, label: 'All (52)' },
                    { id: 'performance' as const, label: 'Performance' },
                    { id: 'sensitivity' as const, label: 'Sensitivity' },
                    { id: 'network' as const, label: 'Network' },
                    { id: 'system' as const, label: 'System' },
                    { id: 'guides' as const, label: 'Guides' },
                  ].map((cat) => (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setCategoryFilter(cat.id)}
                      className={`px-3 py-1.5 rounded-lg font-display text-xs font-bold uppercase whitespace-nowrap cursor-pointer transition-colors ${
                        categoryFilter === cat.id
                          ? 'bg-[#FF1E2D] text-white'
                          : 'bg-[#12151E] text-[#9AA3B2] hover:text-white'
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Numbered Feature Cards List (#01 - #52) */}
              <div className="space-y-2">
                {filteredFeatures.map((feat) => (
                  <button
                    key={feat.id}
                    type="button"
                    onClick={() => setActiveFeature(feat)}
                    className="w-full card-surface rounded-xl p-3.5 text-left flex items-center justify-between gap-3 transition-all cursor-pointer group"
                  >
                    <div className="flex items-start gap-3 min-w-0">
                      <span className="font-mono-tech text-xs font-bold px-2 py-1 rounded-lg bg-[#FF1E2D]/15 text-[#FF1E2D] border border-[#FF1E2D]/30 shrink-0 mt-0.5">
                        {feat.code}
                      </span>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-display font-bold text-sm text-white group-hover:text-[#FF1E2D] transition-colors">
                            {feat.title}
                          </span>
                          <span className="font-mono-tech text-[9px] px-1.5 py-0.5 rounded bg-white/5 text-[#9AA3B2]">
                            {feat.tag}
                          </span>
                        </div>
                        <p className="text-xs text-[#9AA3B2] truncate mt-0.5">
                          {lang === 'si' ? feat.titleSi : feat.shortDesc}
                        </p>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-[#5C6475] group-hover:text-[#FF1E2D] shrink-0" />
                  </button>
                ))}
              </div>
            </div>
          )}
        </main>

        {/* BOTTOM NAVIGATION BAR (4 Clean Thumb-Friendly Tabs) */}
        <nav className="fixed bottom-0 inset-x-0 z-30 bg-[#08090E]/95 border-t border-white/10">
          <div className="max-w-[540px] mx-auto grid grid-cols-4 px-2 py-1.5">
            {[
              { id: 'command' as NavTab, label: 'Command', icon: Flame },
              { id: 'sensitivity' as NavTab, label: 'Sensitivity', icon: Crosshair },
              { id: 'hardware' as NavTab, label: 'Hardware', icon: Cpu },
              { id: 'arsenal' as NavTab, label: '50+ Tools', icon: LayoutGrid },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex flex-col items-center justify-center py-1.5 rounded-xl transition-colors cursor-pointer ${
                    isActive
                      ? 'text-[#FF1E2D] bg-[#FF1E2D]/10'
                      : 'text-[#9AA3B2] hover:text-white'
                  }`}
                >
                  <Icon className="w-4 h-4 mb-0.5" />
                  <span className="font-display text-[11px] font-bold uppercase tracking-wider">
                    {tab.label}
                  </span>
                </button>
              );
            })}
          </div>
        </nav>
      </div>

      {/* Feature Detail Drawer / Modal */}
      <FeatureDetailModal
        feature={activeFeature}
        onClose={() => setActiveFeature(null)}
        telemetry={telemetry}
        fpsHistory={fpsHistory}
        speedTest={speedTest}
        isTestingSpeed={isTestingSpeed}
        onRunSpeedTest={handleSpeedTestWithLog}
        customProfiles={customProfiles}
        onAddCustomProfile={handleAddCustomProfile}
        onApplyCustomProfile={handleApplyCustomProfile}
        historyLog={historyLog}
        onClearHistory={() => {
          setHistoryLog([]);
          try {
            localStorage.removeItem('dark_alpha_history_log');
          } catch {}
        }}
        onLogHistory={logHistory}
        onOpenFlutterModal={() => setFlutterModalOpen(true)}
        onJumpToSensitivity={() => setActiveTab('sensitivity')}
        onTriggerLaunch={() => {
          setActiveTab('command');
          handleLaunchGame(selectedPackage);
        }}
      />

      {/* Real Flutter Android Source Code Studio Modal */}
      <FlutterCodeModal
        isOpen={flutterModalOpen}
        onClose={() => setFlutterModalOpen(false)}
      />
    </div>
  );
}

export default App;
